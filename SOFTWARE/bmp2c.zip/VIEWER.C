/***************************************************
  Example program for BMP2C
  Do not run it on PC, it is only for CASIO AFX2.0.
 ***************************************************/
#include <conio.h>
#include <stdio.h>
#define uchar unsigned char
#define DATA_SIZE 1024
typedef unsigned char BMPTabType [DATA_SIZE];
#include "IMG\pic1.c"
#include "IMG\pic2.c"
#include "IMG\pic3.c"
#include "IMG\pic4.c"
#include "IMG\pic5.c"
#include "IMG\logo.c"

void anykey (void) {
  if (getch()==0) getch ();
}

void init_graph (void) {
/*
  initialize graphics for casio
*/
  asm {
    mov ax,0000h/* ah=0:init graph al - page=0*/
    int 10h;
  }
}

void set_video_page (uchar page) {
/*
  According to BradN's or Dscosphe's "routines.txt" info
  this ah=05 function changes video page, NOT TESTED
*/
  asm {
    mov bh,page
    mov ah,05h
    int 10h
  }
}

void disp_bmp (BMPTabType BmpTab, uchar page) {
/*
  copies whole screen to video page
  if video page is equal to the one set using set_video_page
  then this image will be immediately displayed.
*/
  asm {
    push es
    push si
    push di

    mov ax,1A20h        // 0x1A20 is CASIO's video segment
    mov es,ax           //ES is set
    mov ax,1024         //1024 - is a size of 1 video page
    mul page            //DX:AX<-source * AX
    mov di,ax           //DI is set
    mov si,BmpTab       //DS:SI - source is set;
    CLD                 //clear the direction flag
    MOV CX,512          //how many words to copy
    REP MOVSW           //moving da words DS:SI -> ES:DI

    pop di
    pop si
    pop es
  }
}

void main () {
  clrscr ();
       //1234567890 1234567890
  puts (" --= Demo Viewer =--");
  puts (" by Roeoender  V.0.2");
  puts (" drzodrzo@kki.net.pl");
  anykey ();
  init_graph ();
  disp_bmp (pic1Tab,0);
  anykey ();
  disp_bmp (pic2Tab,0);
  anykey ();
  disp_bmp (pic3Tab,0);
  anykey ();
  disp_bmp (pic4Tab,0);
  anykey ();
  disp_bmp (pic5Tab,0);
  anykey ();
  disp_bmp (logoTab,0);
  anykey ();
}