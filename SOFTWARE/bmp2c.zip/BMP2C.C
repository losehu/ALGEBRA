/*  Jarek 'Roeoender' Wosik
    BMP2C - BitMaP to .C converter.
    Make files that contain your image and can be #included to
    C program.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#define DATA_SIZE 1024 /* =128*64 */
#define DIM_X 128
#define DIM_Y 64
#define DIM_X_B 16 /* dimension X of the image counted in bytes */
#define C_DIM_X 16 /* how many numbers in outputed c file per line:*/
#define uchar unsigned char
/* this is a type of image - it contain only image data */
typedef unsigned char BMPTabType [DATA_SIZE];

void anykey (void) {
  if (getch()==0) getch ();
}

const char CHeader []=
"/**** Created with BMP2C (by Jarek 'Roeoender' Wosik, Freeware) ****/\n"
"/* this file contains image data from BMP tranformed into C table. */\n"
"/* your program should contain following two lines:                */\n"
"/* #define DATA_SIZE 1024                                          */\n"
"/* typedef unsigned char BMPTabType [DATA_SIZE];                   */\n"
"/* and probably: #include \"this_file_name.c\"; :-)                  */\n"
"/* Contact: Jarek 'Roeoender' Wosik: drzodrzo@kki.net.pl           */\n"
"/*******************************************************************/\n"
"BMPTabType ";

const char CMiddle []=
" = {\n  "
;
char CEnd []=
"};\n"
;
/*
 example of the header
 42 4D 3E 04 � 00 00 00 00 � 00 00 3E 00 � 00 00
 00 00 80 00 � 00 00 40 00 � 00 00 01 00 � 01 00
 00 00 00 04 � 00 00 13 0B � 00 00 13 0B � 00 00
 00 00 00 00 � 00 00 00 00 � 00 00 FF FF � FF 00
*/

int open_bmp_file (char *FileNameStr, FILE **handleP) {
 *handleP=fopen (FileNameStr,"rb");//opening the file for reading
  if (*handleP==NULL) return -1;
 /* checking size:*/
  fseek (*handleP,17,SEEK_SET);
  if (getc (*handleP)!=0||getc (*handleP)!=0x80) return -1;
  fseek (*handleP,21,SEEK_SET);
  if (getc (*handleP)!=0||getc (*handleP)!=0x40) return -1;
  return 1;
}

void read_bmp (FILE *handleP,BMPTabType BMPTab) {
  int x;
  int y;
  fseek (handleP,62,SEEK_SET);//62-start of bitmap data in .bmp file
  for (y=0;y<DIM_Y;y++)
    for (x=0;x<DIM_X_B;x++)
      BMPTab [(DIM_Y-1-y)*DIM_X_B+x]=getc (handleP);
}

void translate_bmp_for_casio (BMPTabType BMPsrc,BMPTabType BMPdest) {
/*
  this function translates bmp data to specyfic casio screen memory
  structure.
*/
  uchar row;
  uchar column;
  for (row=0;row<16;row++)//src horizontal
    for (column=0;column<64;column++)//scr vertical
      BMPdest [64*row+column]=BMPsrc [1023-row-16*column];
}

int create_c_file (char *FileNameStr, FILE **handleP) {
  *handleP=fopen (FileNameStr,"wt");//create or update text file
  if (*handleP==NULL) return -1;
  return 1;
}

void write_c_file (BMPTabType BMPTab,char *BMPTabName,FILE *handleP) {
  int i=0;
  fwrite (CHeader,1,sizeof (CHeader)-1,handleP);
  fwrite (BMPTabName,1,strlen (BMPTabName),handleP);
  fwrite (CMiddle,1,sizeof (CMiddle)-1,handleP);
  for (i=1;i<DATA_SIZE;i++) {
    fprintf (handleP,"%u,",(char)~BMPTab [i-1]);
    if (!(i%C_DIM_X)) fprintf (handleP,"\n  ");
  }
  fprintf (handleP,"%u",(char)~BMPTab [DATA_SIZE-1],handleP);
  fwrite (CEnd,1,sizeof (CEnd)-1,handleP);
}

void info (void) {
puts ("\n---------------------------BMP2C v.1.0---------------------------");
puts ("BMP to .c converter by Jarek 'Roeoender' Wosik");
puts ("  USAGE:");
puts ("    BMP2C.EXE src_file.bmp table_var [dest_file.c]");
puts ("  where:");
puts ("    src_file.bmp - BitMaP file name with the image");
puts ("    table_var    - this will be an identifier in your C program");
puts ("                   associated with the image.");
puts ("    dest_file.c  - optional C file name (default is 'pic_file'");
puts ("Additional info:");
puts ("  BMP2C reads 128x64 two colour BMP file");
puts ("  and converts it to .c file with a table containg the image.");
puts ("  Program is useful to include bitmaps in C programs");
puts ("  made for CASIO Algebra FX 2.0.");
puts ("  This image can be displayed with disp_bmp function");
puts ("  (take a look at 'viewer.c').");
puts ("  If you find this program useful then credit me in your prog.");
puts ("  Contact: drzodrzo@kki.net.pl");
}

int main (int argc, char *argv []) {
  FILE *BMPFileP;              //file handle
  FILE *CFileP;                //file handle
  BMPTabType BMPTab;           //stores only image data
  BMPTabType BMPTabTranslated; //same as above but translated to casio screen coords format
  if (argc!=4) {
    info ();
    exit (1);
  }

  if ( open_bmp_file (argv [1],&BMPFileP) !=1) {
    puts ("\nBad file or file not found!\n"
          "Your bitmap file *MUST* be:\n"
          "  2 colour\n"
          "  dimension 128x64 (and NOT 64x128 !)\n"
          "  file size should be 1086 bytes.");
    exit (1);/* END OF PROGRAM */
  }
  if (argc==4) {
    printf ("\nBMP2C: Writing to: \"%s\".", argv[3]);
    create_c_file (argv [3],&CFileP);
  } else
  {
    puts ("\nBMP2C: Writing to default file (pic_file.c).");
    create_c_file ("pic_file.c",&CFileP);
  }

  read_bmp (BMPFileP,BMPTab);
  translate_bmp_for_casio (BMPTab,BMPTabTranslated);
  write_c_file (BMPTabTranslated,argv [2],CFileP);
  fclose (BMPFileP);
  fclose (CFileP);
  return 0;
}