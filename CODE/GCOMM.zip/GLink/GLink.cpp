
#include <port_com.h>
#include <glink.h>

#define GLINK_HEADER   3
#define GLINK_RESEND   1
#define GLINK_FINISHED 2

struct GLinkHeader
{
	unsigned short nSize;
	unsigned short nChecksum;
};

int SendPacket(unsigned int nSegment, unsigned int off_set, unsigned int nSize, unsigned int time_out)
{
	GLinkHeader header;
	char code = GLINK_HEADER;
	char val;
	if(nSize > MAX_PACKETSIZE)
	{
		return GLINK_BADSIZE;
	}
	int count = 0;
	header.nSize = nSize;
	//Calcul le checksum
	asm mov si, off_set;
	asm mov es, nSegment;
	asm mov bx, header.nSize;
	asm xor ax, ax;
boucle:
	asm xor al, es:[si];
	asm inc si;
	asm dec bx;
	asm jne boucle;
	asm mov header.nChecksum, ax;
	do
	{
		if(count == 5)
		{
			return GLINK_MAX_RESEND;
		}
		count++;
		Send(&code, 1);	//Envoi l'identifiant
		//Attend la confirmation
		if(TIME_OUT == Receive(&code, 1, time_out))
		{
			return GLINK_TIMEOUT;
		}
		if(code != GLINK_HEADER) //Si l'octet recu n'est pas valide erreur
		{
			return GLINK_HEADER_ERROR;
		}
		Send(&header, sizeof(header));         //Envoi le header
		Send(nSegment, off_set, header.nSize); //Envoi les infos
		if(TIME_OUT == Receive(&val, 1, 500))  //Attend l'accuse de reception.
		{
			return GLINK_ARQ_TIMEOUT;
		}

	}while(val == GLINK_RESEND);
	if(val != GLINK_FINISHED)
	{
		return GLINK_ARQ_ERROR;
	}
	return GLINK_OK;
}

int SendPacket(void* buf, unsigned int nSize, unsigned int time_out)
{
#ifdef _MSC_VER
	return SendPacket((__segment)buf, (unsigned)buf, nSize, time_out);
#else
	return SendPacket(_DS, (unsigned)buf, nSize, time_out);
#endif
}

int ReceivePacket(unsigned int nSegment, unsigned int off_set, unsigned int nMaxSize, unsigned int time_out)
{
	GLinkHeader header;
	int result;
	char code;
	do
	{
		if(Receive(&code, 1, time_out) == TIME_OUT)
		{
			return GLINK_TIMEOUT;
		}
		if(code != GLINK_HEADER)
		{
			return GLINK_HEADER_ERROR;
		}
		Send(&code, 1);//Envoi la confirmation de d�part
		if(Receive(&header, sizeof(header), 250) == TIME_OUT)
		{
			return GLINK_TIMEOUT;
		}
		result = header.nSize > MAX_PACKETSIZE
				|| header.nSize > nMaxSize
				|| Receive(nSegment, off_set, header.nSize, 150) == TIME_OUT;
		if(!result) //Verifie le packet recu par l'intermediaire du checksum
		{
			asm mov si, off_set;
			asm mov es, nSegment;
			asm mov bx, header.nSize;
			asm xor ax, ax;
boucle:
			asm xor al, es:[si];
			asm inc si;
			asm dec bx;
			asm jne boucle;
			asm sub header.nChecksum, ax;
			result = header.nChecksum;
		}

		code = GLINK_FINISHED;//Reception valide
		if(result)
		{
			code = GLINK_RESEND;//Reception invalide
		}
		Send(&code, 1);//Envoie l'accuse de reception
	}while(result);
	return header.nSize;
}

int ReceivePacket(void* buffer, unsigned int nMaxSize, unsigned int time_out)
{
#ifdef _MSC_VER
	return ReceivePacket((__segment)buffer, (unsigned)buffer, nMaxSize, time_out);
#else
	return ReceivePacket(_DS, (unsigned)buffer, nMaxSize, time_out);
#endif
}
