/*********************************************
**   TOUCHE 4.0							    **
**										    **
**  Copyright (c) John Wellesz 2001 - 2003  **
**  All rights Reserved.				    **
**********************************************/

//Special modified function without unsigned long for calculating date from 2000 to 2179.

struct daytime {
    unsigned day_number; // Total number of day elapsed
    unsigned year;       //.
    unsigned month;           //.
    unsigned day;             //.
    unsigned bi;              //. will be set to 1 if the year is a leap one
    unsigned week_day;        //. day of the week 0 is Sunday
    unsigned week_number;     //. Week number in the year
    unsigned day_numid_in_year; //. day number in year
};


// int make_a_date (struct daytime *day_time, unsigned int the_base_year, int set) {{{
#define YEAR1583_1_1_day_week  6 //Saturday
#define YEAR2000_1_1_day_week  6 //Saturday
#define YEAR1970_1_1_day_week  4 //Thursday THIS IS UNUSED
#define BASE_YEAR 2000 //1583
//Special note for David Quaranta
/*  Cette fonction fait 2 choses: elle retourne la date calcul�e � partir du nombre de jour et/ou elle indique le nombre de
 *  jours correspondant � une date pr�cise conpt�s � partir du 1er janvier d'une ann�e choisie > � 2000 et inf�rieur � 2180.
 *
 *  Pour avoir la date compl�te � partir du nombre de jour il faut mettre le nombre de jour dans l'�l�ment day_number de
 *  la structure daytime. Il faut aussi indiquer l'ann�e de base, pour la calculatrice c'est 2000, et bien s�r donner �
 *  la fonction l'adresse de la structure. L'argument set doit �tre � 0
 *
 *  Pour obtenir le nombre de jour il faut renseigner les �l�ments year, month et day de la structure, donner l'ann�e de base
 *  et mettre set � 1.
 *  Si la date n'existe pas la fonction retourne -1.
 *
 *  Dans les 2 cas si tout va bien elle retourne 0.
 *
 *  WARNING: this function cannot handle dates before 1/1/2000
 */

unsigned int month_day_table[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

int make_a_date (struct daytime *day_time, int set)
{
static unsigned int hold_day_number = 0;
static int already_came = 0;
static unsigned int short_month_day_table[2] = {28, 337};
    unsigned int i, year = BASE_YEAR;//we always starts from 2000 //*** CANNOT BE STATIC
    unsigned int day_numid_in_year, day_to_add;
    unsigned int first_base_year_week_day = YEAR2000_1_1_day_week; //*** CANNOT BE STATIC
    int is_year_bisextile, a;

    if (!set && already_came && (hold_day_number == day_time->day_number)){
		//avoid to re-compute everything
		//if the day number hasn't changed
		return 0;
	}

    //entre 2000 et 2179 il y a 65379 jours donc la fonction ne peut plus calculer au del� de 2179.
    if(set && (!day_time->day || day_time->year>2179 || day_time->year < BASE_YEAR)) {
		already_came = 0;
		return -1;
    }

    hold_day_number = day_time->day_number;//save the number of day
    already_came = 1;

    day_time->day_number = 0xFFFF;//put maximum number of day


    i=0;//set counter
    do { //while (i <= day_time->day_number);

	if ((year == BASE_YEAR)) {//if increment reached the based year switch on it.
	    if (!set) {//find the day of the week.
		day_time->day_number = hold_day_number;
		//we update the first_base_year_week_day with the bas_year one
		first_base_year_week_day = (unsigned)((i + first_base_year_week_day) % 7);
	    }
	    i=0;//now it's like if the loop begin again
	}
	if (set && (year > day_time->year)) {//if the specified date cannot be reached
	    day_time->day_number = 0;
	    already_came = 0;
	    break;//quit
	}
//test if it's a leap year:
	is_year_bisextile = (((year % 4) == 0) && ((year % 100) != 0)) || ((year % 400) == 0);
	short_month_day_table[0] = (month_day_table[1] = is_year_bisextile * 29 + (!is_year_bisextile) * 28);
//day number in current year:
        day_to_add = short_month_day_table[0] + short_month_day_table[1];

	day_numid_in_year = 0;//the number of day in the year
	if ( (i + day_to_add < day_time->day_number) && (!set || year != day_time->year)) {
	    i			+= day_to_add;
	    day_numid_in_year	+= day_to_add;
	    a			 = 12;
	} else//if we have found the year, lets found the month
	    for (a = 0; a<12; a++) {//this adds the number of days of each month
		if (set && (year == day_time->year) && (day_time->month == a)) {
		    // if we are setting and year and month are reached
		    day_time->day_number = i + day_time->day - 1;
		    set = 0; //make like if the whole function was recaled
		}

		if ((i + month_day_table[a]) <= day_time->day_number) {//if the number of day is not overwhelmed
		    i += month_day_table[a];//update counter
		    day_numid_in_year += month_day_table[a];//update day number in year
		} else break;
	    }

	if (!set) {
	    if (a != 12) {
		day_time->year = year;
		day_time->month = a;
		day_time->day = (unsigned int)(day_time->day_number - i + 1);
		day_time->bi = is_year_bisextile;
		day_time->day_numid_in_year = (day_numid_in_year += day_time->day);
		day_time->week_number = day_numid_in_year / 7;
		if (((unsigned)
			((day_time->day_number - (day_time->day_numid_in_year - 1) + first_base_year_week_day) % 7L)) < 5)
		    day_time->week_number += 1;
		else if (!day_time->week_number) day_time->week_number = 53;
		break;
	    }
	}
	year++;

    } while (i <= day_time->day_number);

    day_time->week_day = (unsigned)((day_time->day_number + first_base_year_week_day) % 7L);
    return (year > day_time->year) * -1;
}// }}}     
