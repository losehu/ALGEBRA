/************************************************************************
 *								GCOMM									*
 *																		*
 * Programme ecrit par David Quaranta									*
 * Ce programme utilise des lib de 2072 (memzone et jwdate)				*
 * (C) Copyright 2003-2004 Quaranta David								*
 ************************************************************************/


#include <dos.h>
#include <direct.h> 
#include <process.h>

#include <graphic.h>
#include <ascii.h>
#include <memzones.h>
#include <boite.h>
#include <glink.h>
#include <port_com.h>
#include <keys.h> 
#include <def.h>    
#include <utils.h>

#include "GComm.h"
#include "jwdate.c"	//code de 2072 pour gerer la date

#define _FR		/* Francais */
//#define _EN		/*Anglais */

#include "lang_fr.h"
#include "lang_en.h"


#define NZ_GROUP "GRP"
#define NZ_LOCAL "LCL"
#define NZ_DT8   "DT8"
#define NZ_DT9   "DT9"
#define NZ_OTHER ""


#define GCOMM_SENDRAM_PACKETSIZE 4096

#define MAXZONE_SCANNED 15
#define NUMZONE_CREATED 12
/** Nom des zones scan�es */
char* sZoneName[] = {NZ_BASIC, NZ_GROUP, NZ_SYSTEME, NZ_CHAR, NZ_LISTE, NZ_MATRICE,
							NZ_IMAGE, NZ_XLECT, NZ_LOCAL, NZ_DT8, NZ_DT9, NZ_ADDIN, NZ_OTHER, NZ_OTHER, NZ_OTHER};
							
//verifier batterie
//if (inp(0x52)==0x6)//

//Pour le protocole Casio de LINK
unsigned char header_start[] = {58,77,68,76,49,90,88,57,52,53,255,48,
						51,56,52,48,48,78,49,46,48,48,0,0,16,0,0,0,4,0,0,0,1,0,48,120,48,
						55,255,64};
unsigned char exportdrive[] = {58,65,68,78,49,73,78,70,49,0,0,4,0,
		0,0,0,128,0,2,0,0,255,255,255,255,255,255,255,255,255,255,
		255,255,255,255,255,255,255,255,122};
unsigned char importdrive[] = {0x3A, 0x52, 0x45, 0x51, 0x31, 0x49, 0x4E, 0x46, 0x31, 0xFF,
			 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
			 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
			 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xF7};
unsigned char closecom[] = {58,69,78,68,49,255,255,255,255,
		255,255,255,255,255,255,255,255,255,255,255,255,
		255,255,255,255,255,255,255,255,255,255,255,255,
		255,255,255,255,255,255,26};

char* sSel[] = {" ", ">"};

unsigned int nSpeeds[]	= {144, 384, 576, 1152};
unsigned char nValues[] = {1, 4, 5, 7};


char* sReboot[]			= {SREBOOT};
char* sDisplay[]		= {SDISPLAY};
char* msg_yesno[]		= {YESNO};
char* msg_drivestate[]	= {SDRIVE_STATE};
char* msg_mainmenu[]	= {MSG_MAINMENU};
char* msg_sendmenu[]	= {MSG_SENDMENU};
char* msg_outilsmenu[]	= {MSG_OUTILSMENU};
char* msg_systemmenu[]	= {MSG_SYSTEMMENU};
char* msg_optionsmenu[]	= {MSG_OPTIONSMENU};

char* msg_option_icon_editor[]		= {MSG_OPTION_ICON_EDITOR};
char* msg_option_gicon_editor[]		= {SCOPY, SCOPYALL, SINVERTIMAGE, SCLEAR, SPREVIEW, SINVERTBORDER};
char* msg_protocol[]				= {MSG_PROTOCOL};
char* msg_option_memory_manager[]	= {MSG_OPTION_MEMORY_MANAGER};
char* sDrives[]						= {SdRIVES};
char* msg_option_flash_manager[]	= {MSG_OPTION_FLASH_MANAGER};
char* msg_option_preview[]			= {MSG_OPTION_PREVIEW};
char sSending[]						= SENDING;
char sReceiving[]					= RECEIVING;


/** Initialise les mots pour les boites de dialogues */     
char msg_cancel[] = MSG_BOX_CANCEL;
char msg_ok[]     = MSG_BOX_OK;
char msg_yes[]    = MSG_BOX_YES;
char msg_no[]     = MSG_BOX_NO;     
     
unsigned char mMapDrives[] = {0xA0, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xC0};

char max_options[] = {4, 3, 4, 2, 2};
char options[]     = {3, 2, 3, 1, 1};
char gcomm[] = "GComm";
int  nShowTime;
int  nReboot;
int  nApo;
daytime day_time; //date
int m_nYMax;//Y max pour �crire.

unsigned int far* apo = ADDRESS_OF_APO; //Auto Power Off

#define GETOFFSETMENU(n) ((unsigned)(menus)) + (n << 10) + 57

__inline void MAPPER_EN_4000(unsigned int nDrive)
{
 	asm mov si, OFFSET mMapDrives;
 	asm add si, nDrive;
	asm mov al, ds:[si];
	asm out 0x56, al;
}

__inline void MAPPER_EN_6000(unsigned int nDrive)
{
 	asm mov si, OFFSET mMapDrives;
 	asm add si, nDrive;
	asm mov al, ds:[si];
	asm out 0x57, al;
}  

void rebootcalc()
{
	// Fait rebooter la calculatrice Bugbug&BradN	
	(*(void (far*)()) MK_FP(0xFFFF,0x0))();
}

//Handler pour le menu flash
void FlashDisplay(int y, int nIndex, void** arg)
{
	static char* sText[] = {"%s%s", "%s%s->%s"};
	char* sel    = (char*)arg[0]; 
	char* drives = (char*)arg[1];  
	print2(2, y, sText[sel[nIndex]], sSel[sel[nIndex]], sDrives[nIndex],           
				sDrives[drives[nIndex]]);
}  

//Handler pour le menu option
void OptionDisplay(int y, int nIndex, void** arg)
{	
	print2(2, y, msg_optionsmenu[nIndex], arg[nIndex]);
}  

/** Handler pour le menu gestionnaire de flash */
void FlashManagerDisplay(int y, int nIndex, void** arg)
{
	print2(2, y, "%s:%s", sDrives[nIndex], msg_drivestate[((char*)arg)[nIndex]]);
}  

/** Handler pour le gestionnaire de RAM et Envoi de RAM */
void RAMManagerDisplay(int y, int nIndex, void** arg)
{
	static char* sPassword[] = {" ", "*"};
	TRAM* files = ((TRAM*)arg[0]) + nIndex;
	print2(2, y, "%s%s", sSel[files->sel], files->name);
	if(files->id)
	{
		memory_zone bf;
		long size = search_mem_zone(files->id, (unsigned char*)files->name, &bf);
		print2(10 * WIDTH_SPACE, y, "%s %.5l %s", sPassword[bf.b_password[0] != '\0'], size, sZoneName[files->id - 1]);
	}
}
/** Handler pour le gestionnaire de RAM permettant d'afficher la place restante */
void RAMManagerExtraHandler(void** arg)
{
	ClearLine(m_nYMax);
	print2(2, m_nYMax, SBYTES_FREE, afxleft());
}

/** Handler pour l'�diteur d'icone */
void EditIconDisplay(int y, int nIndex, void** arg)
{
	static char* text[] = {NAME, BMP, PATH, ARGUMENTS, VERSION, SHOWINSYSTEM};
	print2(2, y, "%s:%s", text[nIndex], arg[nIndex + 2]);
}

/** Handler pour l'�diteur d'icone permettant d'afficher le num�ro de l'icone */
void IconExtraHandler(void** arg)
{
	print2((128 - 5*WIDTH_SPACE)>>1, m_nYMax, "%.2i/%.2i", (int)arg[0]+1, (int)arg[1]);
}

#define OPTION_SIZE (14 + sizeof(options))

void main()
{
	int key;                 
	memory_zone bf;

	if(search_mem_zone(3, (unsigned char*)"FONT", &bf) == 1024 + 14)
	{
		my_movedata(bf.b_segment, bf.b_inner_offset, SEG2, 0, 1024, 0);
   		setFont(MK_FP(SEG2, 0), 4, 5);
   	}
    
	//Lecture du fichier de config GComm
	if(search_mem_zone(12, (unsigned char*)gcomm, &bf) == OPTION_SIZE)
	{
		read_mem_zone(&bf, options, 0, sizeof(options));
		for(key = 0; key < sizeof(options); key++)
		{
			options[key] = options[key] % max_options[key];
		}
	}

	//Sauvegarde la valeur de l'APO & coupe l'APO par la suite
	nApo = *apo;
	*apo = 0;

	int nStart = 0;
	int choix  = 0;
	while(1)
	{
		//Cr� le fichier ou v�rifie qu'il soit � la bonne taille
		if(resize_mem_zone(12, gcomm, OPTION_SIZE, &bf) != -1)
		{		
			//Sauvegarde les options
			write_mem_zone(&bf, options, 0, sizeof(options));
		}
		nShowTime = options[2];
		m_nYMax   = 64 - HEIGHT - (nShowTime != 0) * (HEIGHT_SPACE + 1);
		nReboot   = 0;	
		key       = ShowMenuSelection(msg_mainmenu, 5, nStart, choix, 4);
		if(key == K_ESC)
		{
			Quitter();
		}
		if(key == K_F1)
		{
			choix = 0;
		}
		if(key == K_F2)
		{
			choix = 1;
		}
		switch(choix)
		{
		case 0:
			ShowSendMenu();
			break;
		case 1:
			OnReceiveMode();
			break;
		case 2:
			ShowToolsMenu();
			break;
		case 3:
			ShowOptionsMenu();
			break;
		case 4:
			ShowClock();
			break;
		}
	}
}

void ErrorComm()
{    
	MsgBox(0, RECEIVE_ERROR);
	/** N'appelle pas CloseComm() pour �viter de red�marrer la machine si reboot est modifi�,
	 * pour que l'on puisse relancer le transfert.
	 */
	ClosePort();
}

void CloseComm()
{  
	ClosePort();
	if(nReboot&2 || nReboot && options[1] == 2)
	{
		rebootcalc(); //Reboot caltos
	}
	if(nReboot && options[1] == 1)
	{
		Quitter();
	}
}

int InitComm(PROTOCOL nProtocol)
{
	if(nProtocol == PR_G100)
	{
		unsigned char buf[40];
		InitPort(4); //Comm a 38400 bps
		Receive(buf, 1, 2000);
		if(buf[0] != 19)
		{
			return 0;
		}
		SendForCasio(header_start, sizeof(header_start));
		if(Receive(buf, sizeof(buf), 2000) == TIME_OUT)
		{
			return 0;
		}
		return SendStart();
	}
	InitPort(nValues[options[0]]);
	return 1;
} 

void EndTransfert(PROTOCOL nProtocol, int nStatus)
{
	if(nStatus <= 0)
	{
		ErrorComm();
		return;
	}
	switch(nProtocol)
	{
	case PR_G100:  
		Send(closecom, sizeof(closecom));
		break;
	case PR_GCOMM:
		THeader header;
		header.type = TRANSFERT_EXIT;
		SendPacket(&header, sizeof(header) , 400);
	}                                             
	CloseComm();
}

void Quitter()
{
	*apo = nApo;
	asm mov ax, 0x4C00;
	asm int 0x21;
}

void SendForCasio(const void* buffer, unsigned int nSize)
{
	for(unsigned int i = 0; i < nSize; i++)
	{
		Send(((const char*)buffer)+i, 1);
		Delay(1);
	}
}

void ClearLine(int l)
{
	for(int y = 0; y < HEIGHT_SPACE; y++)
	{
		hLine(1, l + y, 126, 0);
	}
}

void InvertLine(int k)
{
	for(int y = 0; y < HEIGHT_SPACE; y++)
	{
		invhLine(1, k + y, 126);
	}
}

void Inv2Lines(int l1, int l2)
{
	invhLine(1, l1, 126);
	invhLine(1, l2, 126);
	Delay(2);
}


void PrintTitle(const char* title, int y)
{
	alignPrint(title, y, 0, 127, TEXT_CENTER);
	
	invhLine(2, y, 125);        
	invhLine(1, y+1, 126);
	for(int i = 2; i < HEIGHT_SPACE; i++)
	{
		invhLine(0, i + y, 127);
	}
}

void ShowTitleMenu(const char* title)
{
	static const char* pLastTitle = NULL; 
	static int nLastShowTime;

	if(pLastTitle != title)
	{
		if(pLastTitle == NULL || options[4] == 0)
		{
			clear();   
			PrintTitle(title, 0);
			vLine(  0, 2, 63, 1);
			vLine(127, 2, 63, 1);
		}
		else
		{
			int i;
			int max = 63;
			if(nShowTime && (nShowTime == nLastShowTime)){
				max -= HEIGHT + 2;
			}                         
			for(i = 0; i <= max; i++)
			{			
				vShift(0, 15, 0, max, -1);
				hLine(0, i, 127, 0);
			}
			PrintTitle(title, max - HEIGHT);
			for(i = max; i > HEIGHT; i--)
			{			
				vShift(0, 15, 0, max, 1);
				hLine(1, i, 126, 0);
			}
		}
		pLastTitle    = title; 
		nLastShowTime = nShowTime;
	}
}

unsigned int ExploreRAM(TRAM* files, unsigned int nMax)
{
	unsigned int n = 0;
    char far *curent_b_ptr;
    
    //Initialise tout � z�ro
	init_area((__segment)files, (unsigned)files, nMax * sizeof(TRAM), 0, 0);
	
	for(int zone_id = 1; zone_id <= MAXZONE_SCANNED; zone_id++)
	{
		curent_b_ptr = tell_mem_zone_seg(zone_id);
		 
		while(curent_b_ptr[2] == zone_id && n < nMax)
		{
			my_movedata(_FP_SEG(curent_b_ptr), _FP_OFF(curent_b_ptr)+3, (__segment)(files), (unsigned)(files+n), 8, 0);
			files[n].id = zone_id;
			curent_b_ptr = (char far *)add_transit(curent_b_ptr, *((u_int far *)(curent_b_ptr)));
			n++;
		}
	}
	return n;
}

void Delay(unsigned int time)
{
	for(int i = 0; i < time; i++)
	{
		asm mov ax, 3000;
boucle:	asm dec ax;
		asm cmp ax, 0;
		asm jne boucle;
	}
}

int WaitKey()
{
	int r;
	while(!(r = ReadKey()))
	{
		asm hlt;
	}
	return r;
}

int ReadKey()
{
	int key;	
	asm mov ah, 01h;
	asm int 16h;
	asm jz nokey;
	asm mov ah, 10h;
	asm int 16h;
	asm mov key, ax;
	return key;
nokey:
	if(nShowTime)
	{
		int nY = 64 - HEIGHT;
		hLine(0, nY - 2, 127, 1);
		if(nShowTime&1) //Affiche l'heure
		{
			int min;
			asm in ax, 0x1E;
			asm mov min, ax;
			print2(127 - 5*WIDTH_SPACE, nY, "%.2i:%.2i", min>>8, min&0xFF);
		}
		if(nShowTime&2) //Affiche la date
		{
			asm in ax, 0x20;			
			asm mov day_time.day_number, ax;
			make_a_date(&day_time, 0);
#ifdef _FR
			print2(2, nY, "%.2i/%.2i/%i", day_time.day, day_time.month+1, day_time.year);
#endif
#ifdef _EN
			print2(2, nY, "%.2i/%.2i/%i", day_time.month+1, day_time.day, day_time.year);
#endif
		}
	}
	return 0;
}

void DisableKeyboard()
{
	DISABLEKEYBOARD;
} 

void EnableKeyboard()
{
	ENABLEKEYBOARD;
}

int ExportDrive(int nDrive, int nSourceDrive, PROTOCOL nProtocol)
{
	DisableKeyboard();
    ShowProgressPopup(0, 0, sSending, sDrives[nSourceDrive]);
	unsigned int nNbSeg;

	unsigned char nChar;
	int result;
	unsigned int nSend;
	if(nProtocol == PR_GCOMM)
	{
		//Protocole pour GComm
		THeader header;
		header.type = TRANSFERT_IMPORTDRIVE;
		header.name[0] = nDrive;
		nNbSeg = GetSizeUseful(nSourceDrive);//Taille du lecteur (donnees utiles)
		
		header.size = nNbSeg;

		//Envoi la taille du lecteur et demande l'importation
		//et attend la fin du formatage
		if((SendPacket(&header, sizeof(header), 1000) < 1)
			|| (ReceivePacket(&nChar, sizeof(nChar),  4000) < 1)
			|| nChar != TRANSFERT_GO)
		{
			result = -1;
		}
		nSend  = (2048 >> 4);
	}
	else
	{
		//Protocole Casio
		if(nDrive)
		{
			exportdrive[5]	= 'F';
			exportdrive[6]	= 'R';
			exportdrive[7]	= '0';
			exportdrive[8]	= nDrive + 48;
			exportdrive[39] = 144 - nDrive;
		}
		else
		{
			exportdrive[5]	= 73;
			exportdrive[6]	= 78;
			exportdrive[7]	= 70;
			exportdrive[8]	= 49;
			exportdrive[39] = 122;
		}
		SendForCasio(exportdrive, 40);
		result = Receive(&nChar, 1, 7000);
		nNbSeg = 8192;    
		nSend  = (1024 >> 4);
	}
	MAPPER_EN_4000(nSourceDrive);
	unsigned int segment = 0x4000;
	unsigned int n = nNbSeg>>4;
	while(result > 0 && nNbSeg)
	{
		if(nProtocol == PR_GCOMM)
		{
			if(nNbSeg < nSend)
			{
				nSend = nNbSeg;
			}
			result = SendPacket(segment, 0, (nSend << 4), 600);
		}
		else
		{
			nChar = 58;
			Send(&nChar, 1);
			asm mov es, segment;
			asm xor di, di;
			asm xor ax, ax;
boucle:
			asm add al, es:[di];
			asm inc di;
			asm cmp di, 1024;
			asm jne boucle;
			asm mov bx, 256;
			asm sub bx, ax;
			asm mov nChar, bl;
			Send(segment, 0, 1024);
			Send(&nChar, 1);
			if(Receive(&nChar, 1, 1500) == TIME_OUT || nChar != 6)
			{
				result = -1;
			}
		}
		segment += nSend;
		nNbSeg  -= nSend;
	    ShowProgressPopup(0, (100*((segment - 0x4000)>>4)) / n, 0);
	}
	EnableKeyboard();    
	CloseBox();
	return result;
}

void EraseSegment(unsigned int nSegment)
{
	asm mov es, nSegment;
	asm mov es:[0xAAA], 0xAA;
	asm mov es:[0x554], 0x55;
	asm mov es:[0xAAA], 0x80;
	asm mov es:[0xAAA], 0xAA;
	asm mov es:[0x554], 0x55;
	asm mov es:[420  ], 0x30;
	//Attend la fin du formatage du secteur
waiting:
	asm mov bl, es:[0xFF];
	asm cmp bl, 0xFF;
	asm jne waiting;
}


unsigned int UsedArea(unsigned int nSegment, unsigned int nSize)
{
	asm mov cx, nSegment;
	asm mov dx, nSize;
	asm mov bx, cx;
	asm add cx, dx;
check:
	asm dec cx;
	asm mov es, cx;		
	asm mov ax, es:[0];
	asm and ax, es:[2]; 
	asm and ax, es:[4];
	asm and ax, es:[6];
	asm and ax, es:[8];
	asm and ax, es:[10];
	asm and ax, es:[12];
	asm and ax, es:[14];
	asm cmp ax, 0xFFFF;
	asm jne noempty;
	asm cmp cx, bx;
	asm jne check;
	asm jmp fin;
noempty:
	asm inc cx;
fin:
	asm mov nSegment, cx;
	return nSegment;
}

unsigned int EraseDrive(int nDrive)
{
	static unsigned int step[5] = {0x0400, 0x0200, 0x0200, 0x0800, 0x1000};//systeme
					
	unsigned int segment = 0x4000;
	int count = 0;	
	unsigned int nSize;
	
    //Affiche un popup pour informer du d�but du formatage
    ShowProgressPopup(0, -1, MSG_FORMAT, sDrives[nDrive]);

	//Mappage
	MAPPER_EN_4000(nDrive);
	
	//Verifie si des secteurs sont vides, pour ne pas les formater
	while(segment < 0x6000)
	{
		if(nDrive)
		{
			nSize = 0x1000;
		}
		else
		{
			nSize = step[count++];
		}
		if(UsedArea(segment, nSize) != segment)
		{
			EraseSegment(segment);
		}
		segment += nSize;
	}

	//Formatage Fini 
	CloseBox();
	return 0x4000;
}

unsigned int GetSizeUseful(int nDrive)
{
	//Mappage
	MAPPER_EN_4000(nDrive);

	unsigned int nSeg = UsedArea(0x4000, 0x2000) - 0x4000;
	return nSeg;
}

int ImportDrive(int nDrive, int nNbSeg)
{
	unsigned int segment = EraseDrive(nDrive);

	//Commence le transfert
	ShowProgressPopup(0, -1, RECEIVING, sDrives[nDrive]);
	
	//Desactive le clavier
	DisableKeyboard();
	
	//Ecriture dans la Flash
	char type = TRANSFERT_GO;
	int r = SendPacket(&type, 1, 700);
	unsigned int nSeg = 0; //Secteur recu
	while(r > 0 && nSeg < nNbSeg)
	{
		r = ReceivePacket(SEG4, 0, 2048, 700);
		if(r > 0)
		{
			WriteInFlash(segment, (nSeg << 4), SEG4, 0, r);
			nSeg += (r >> 4);
			if(nSeg == 4096){
				segment += 0x1000;
			}
		}
	}
	
	EnableKeyboard();      
	CloseBox();	
	return r;
}

int GetNbIcons(TInfo* infos)
{
	int i = 0;
	for(; i < 35 && infos[i].number != -1; i++);
	return i;
}

int GetNbMenus(TInfo* infos)
{
	int n = GetNbIcons(infos);
	if(n > 12)
	{
		return (n >> 2) - 2 + ((n&3) != 0);
	}
	else
	{
		return 1;
	}
}

void ReadMenu(TInfo* infos, TMenu* menus)
{
	//Mappage
	asm mov al, 0xA0;
	asm out 0x56, al;
	                    
	my_movedata(0x4000, 0x4000, (__segment)infos, (unsigned)infos, 2310, 0);
	my_movedata(0x4000, 0x6000, (__segment)menus, (unsigned)menus, 7168, 0);
}

int AddIcon(TInfo* infos, TMenu* menus)
{
	int n = GetNbIcons(infos);
	if(n >= 35)
	{
		MsgBox(0, MAXICONREACHED);
		return n - 1;
	}
	char* buf = (char*)&(infos[n]);
	for(int i = 0; i < sizeof(TInfo); i++)
	{
		buf[i] = 0;
	}
	infos[n].number	= n;
	infos[n].bmp	= infos[n - 1].bmp;

	//Mettre a jour le menu si un nouveau menu est cree lors de l'ajout de l'icone
	int menu = GetNbMenus(infos) - 1;
	if(menu > 0 && (n&3) == 0)
	{
		//Copie le titre et les 8 dernieres icones
		int dec = 19;
		for(i = 19; i < 64; i++)
		{
			if(i == 57)
				dec = 0;
			for(int j = 0; j < 1024; j += 64)
			{
				menus[menu].menu[i + j] = menus[menu - 1].menu[i + j - dec];
			}
		}
		//Efface les 19 dernieres lignes de l'ecran
		for(i = 0; i < 19; i++)
			for(dec = 0; dec < 1024; dec += 64)
				menus[menu].menu[i + dec] = 0;
	}
	return n;
}

void ShowInSystem(TInfo* infos, int n, int show)
{
	int found = 0;
	int i;
	if(show)
	{
		infos[n].bmp = 2;
		for(i = 0; i < n; i++)
		{
			if(found)
			{
				infos[i].bmp = 2;
			}
			found = infos[i].bmp == 2;
		}
	}
	else
	{
		i = n;
		do
		{
			infos[i].bmp = 1;
			i++;
		}while(n && infos[n - 1].bmp == 2 && i < 35 && infos[i].number != -1);
	}
}

void WriteInFlash(unsigned int nSegment, unsigned int nOffset, unsigned int nSegSource, unsigned int nOffsetSource, unsigned int nSize)
{
	asm push ds;
	asm mov es, nSegment;
	asm mov si, nOffset;
	asm mov di, nOffsetSource;
	asm mov bx, nSize;
	asm mov ds, nSegSource;
boucle:
	asm mov al, ds:[di];
	asm mov es:[0xAAA], 0xAA;
	asm mov es:[0x554], 0x55;
	asm mov es:[0xAAA], 0xA0;
	asm mov es:[si], al;
waiting:
	asm mov cl, es:[si];
	asm cmp cl, al;
	asm jne waiting;
	asm inc di;
	asm inc si;
	asm dec bx;
	asm cmp bx, 0;
	asm jne boucle;
	asm pop ds;
}

void UpdateMenu(TInfo* infos, TMenu* menus)
{
	asm mov al, 0xA0;
	asm out 0x56, al;

	//Copie la fin du secteur des informations et des menus
	my_movedata(0x4000, 0x5FA0, SEG4, 0, 96, 0);
	my_movedata(0x4000, 0x7FF0, SEG4, 100, 16, 0);

	//Demande de formater le secteur contenant les informations sur les icones (8Ko, a l'offset 0x4000)
	//et aussi les le secteur contenant les menus
	EraseSegment(0x4400);
	EraseSegment(0x4600);
	//Formatage termin�

	//Ecrire les infos sur les icones (35 * 66 octets)
	WriteInFlash(0x4000, 0x4000, (__segment)infos, (unsigned)infos, 2310);

	//Ecrire la fin du secteur des informations (copie precedement)
	WriteInFlash(0x4000, 0x5FA0, SEG4, 0, 96);

	//Ecrire les nouveaux menus (7 * 1024 octets)
	WriteInFlash(0x4000, 0x6000, (__segment)menus, (unsigned)menus, 7168);

	//Ecrire la fin du secteur
	WriteInFlash(0x4000, 0x7FF0, SEG4, 100, 16);
}

void CopyTitle(unsigned int nSegment, unsigned int nOffset, unsigned int nSegSource, unsigned int nOffsetSource)
{
	asm push ds;
	
	asm mov si, nOffset;
	asm mov di, nOffsetSource;
	asm mov es, nSegment;
	asm mov ds, nSegSource;
	asm xor al, al;
b1:
	asm mov bx, ds:[di]		asm mov es:[si], bx;
	asm mov bx, ds:[di+2]	asm mov es:[si+2], bx;
	asm mov bx, ds:[di+4]	asm mov es:[si+4], bx;
	asm mov bl, ds:[di+6]	asm mov es:[si+6], bl;
	asm add si, 64;
	asm add di, 64;
	asm inc al;
	asm cmp al, 16;
	asm jne b1;

	asm pop ds;
}

int GetShift(int nLine, int nY)
{
	int y = nY - nLine*HEIGHT_SPACE;
	if(y < 0)
	{
		y = (nY % HEIGHT_SPACE);
	}           
	return (y >> 1) + HEIGHT_SPACE; 

}
 
int ShowMenuSelection(char** msg, int nLine, int& nStart, int& nChoix, int nMaxStopKeys, DisplayHandler handler, void** arg, ExtraHandler extra, int nRemoveRow)
{
	static int stopkeys[] = {K_ESC, K_EXE, K_F1, K_F2, K_DEL, K_OPTN, K_LEFT, K_RIGHT};
	int key, i, l;
	
	ShowTitleMenu(msg[0]);
	if(extra)
	{
		extra(arg);
	}
	if(nLine == 0)
	{
		return WaitKey();
	}

	int nYMax  = m_nYMax - nRemoveRow;
	int nDec   = GetShift(nLine, nYMax);
	int nLimit = nYMax / HEIGHT_SPACE;
	int bMultiScreen = (nLine > nLimit);
	int bDoRefresh = 1;
	if(nStart + nLimit > nLine)
	{
		nStart = 0;
		if(bMultiScreen)
		{
			nStart = nLine - nLimit;
		}
	}	
	if(nChoix >= nLine)
	{
		nChoix = nLine - 1;
	}

	nChoix -= nStart;

	setWordWrap(0);
	while(1)
	{
		l = HEIGHT_SPACE*nChoix + nDec;
		if(bDoRefresh)
		{
			int y     = nDec;
			int index = nStart; 
			while(y <= nYMax  && index < nLine)
			{
				ClearLine(y);
				if(handler)
				{
					handler(y, index, arg);
				}
				else
				{
					alignPrint(msg[index+1], y, 0, 127, TEXT_CENTER);
				}
				if(l == y)
				{         
					InvertLine(l);
				} 
				y += HEIGHT_SPACE; 
				index++;
			}
			bDoRefresh = 0;
		}

		key = WaitKey();
		 
		if(key == K_CTRL)
		{
			if(nStart >= nLimit)
			{
				nStart -= nLimit;
			}
			else
			{
				nStart = 0;
			}
			bDoRefresh = 1;
		}
		if(key == K_VARS)
		{
			nStart += nLimit;
			if(nStart >= nLine - nLimit)
			{
				nStart = nLine - nLimit;
			}
			if(nStart < 0)
			{
				nStart = 0;
			}
			bDoRefresh = 1;
		} 
				
		if(key == K_DOWN)
		{
			if(nChoix == nLimit - 1 && bMultiScreen)
			{
				nStart++;
				if(nStart + nLimit > nLine)
				{
					nChoix = nStart = 0;
				}
				bDoRefresh = 1;
				continue;
			}
			nChoix = (nChoix + 1) % nLine;
			for(i = 0; i < HEIGHT_SPACE; i++)
			{
				Inv2Lines(l+i, HEIGHT_SPACE*nChoix+nDec+i);
			}
		}
		if(key == K_UP)
		{
			if(nChoix == 0 && bMultiScreen)
			{
				if(nStart)
				{
					nStart--;
					nChoix = 0;
				}
				else
				{
					nStart = nLine - nLimit;
					nChoix = nLimit - 1;
				}
				bDoRefresh = 1;
				continue;
			}
			nChoix = (nChoix + nLine - 1) % nLine;
			for(i = HEIGHT; i >= 0; i--)
			{
				Inv2Lines(l+i, HEIGHT_SPACE*nChoix+nDec+i);
			}
		}
		for(i = 1; i <= nLine && i <= nLimit; i++)
		{
			if(chiffres[i] == key)
			{
				nChoix = i - 1;
				key = K_EXE;
				goto quit;
			}
		}
		for(i = 0; i < nMaxStopKeys; i++)
		{
			if(key == stopkeys[i])
			{
				goto quit;
			}
		}
	}//End of while(1)
	
quit:
	InvertLine(l);
	nChoix += nStart;
	setWordWrap(1);
	return key;
}

int ShowRAMSelection(char** msg, TRAM* files, int& choix, int& start, int n, int nRemoveRow, ExtraHandler extra)
{
	int key;    
	
	key = ShowMenuSelection(msg, n, start, choix, 5, RAMManagerDisplay, (void**)&files, extra, nRemoveRow);

	if(key == K_F1)
	{
		files[choix].sel ^= 1;
	}
	if(key == K_F2)
	{
		for(int i = 0; i < n; i++)
		{
			if(files[i].id == files[choix].id)
			{
				files[i].sel ^= 1;
			}
		}
	}
	return key;
}

int EditImag(unsigned int& cpt, int& x, int& y, int& n, int nb, int left, int top, int maxX, int maxY)
{
	int key;
	int inv = 0;
	do
	{
		key = ReadKey();
		//Lecture du compteur interne de la G100 pour le clignotement du curseur
		if(((*internal_cpt -  cpt > 32) && !key) || (key && inv))
		{
			invhLine(x, y, x);
			inv ^= 0xFF;
			cpt  = *internal_cpt;
		}
		if(key){
			cpt = 0;
		}
		if(key == K_DOWN && y < maxY)
			y++;
		if(key == K_UP && y > top)
			y--;
		if(key == K_LEFT && x > left)
			x--;
		if(key == K_RIGHT && x < maxX)
			x++;
		if(key == K_CTRL || key == K_VARS)
		{
			hLine(x, y, x, key == K_CTRL);
			return 0;
		}
		if(key == K_F1)
		{
			n = (n + nb - 1)%nb;
			return 1;
		}
		if(key == K_F2)
		{
			n = (n+1)%nb;
			return 1;
		}
		if(key == K_ALPHA)
		{
			char text[26];
			int max = maxY - HEIGHT + 1;
			if(y > max)
			{
				y = max;
			}
			if(x + WIDTH_SPACE > maxX)
			{
				x = maxX - WIDTH_SPACE + 1;
			}
			max = (maxX - x) / WIDTH_SPACE;
			int insert = 0, mode = 2;
			return 1 - InputText(x, y, text, max, insert, mode, 1);
		}
	}while(key != K_EXE && key != K_ESC && key != K_OPTN);
	return key;
}

int Byte(unsigned int nSeg, unsigned int nOffset, int x, int y, unsigned int val, unsigned int mask)
{
	int decalage = 8 - (x&7);
	x = 127 - x;
	y = 63 - y;
	asm mov es, nSeg;
	asm mov si, x;
	asm shr si, 3;
	asm shl si, 6;
	asm add si, nOffset;
	asm add si, y;
	asm mov dx, mask;
	asm mov cx, decalage;
	asm mov bx, val;
	asm cmp bx, 0xFFFF;
	asm je get;
	asm shl bx, cl;
	asm shl dx, cl;
	asm mov ax, 0xFF;
	asm shl ax, cl;
	asm and ax, dx;
	asm and bx, ax;
	asm xor ax, 0xFFFF;

	asm and es:[si], ah;
	asm and es:[si - 64], al;

	asm or es:[si], bh;
	asm or es:[si - 64], bl;
	return 1;
get:
	asm mov ah, es:[si];
	asm mov al, es:[si - 64];
	asm shr ax, cl;
	asm mov decalage, ax;
	return decalage;
}

void CopyIcon(unsigned int nSegDest, unsigned int nOffsetDest, int nDest, unsigned int nSegSource, unsigned int nOffsetSource, int nSource)
{
	int xDest	= 30 * (nDest&3);
	int yDest	= 19 * (nDest >> 2);
	int xSource	= 30 * (nSource&3);
	int ySource	= 19 * (nSource >> 2);
	unsigned int mask = 0xFFFF;
	for(int x = 0; x < 30; x += 8)
	{
		if(x == 24)
		{
			mask = 0xFFFC;
		}
		for(int y = 7; y < 26; y++)
		{
			unsigned int val = Byte(nSegSource, nOffsetSource, x + xSource, y + ySource, 0xFFFF, mask);
			Byte(nSegDest, nOffsetDest, x + xDest, y + yDest, val&0xFF, mask);
		}
	}
}

int GetFirstMenuOfIcon(int num)
{
	int n = num >> 2;
	if(n > 2)
	{
		return n - 2;
	}
	return 0;
}

int ShowEditorPopup(int nNum, int x1, int y1, int x2, int y2, int nMax, TInfo* infos, TMenu* menus)
{
	int n = ShowInputPopup(msg_option_gicon_editor, nNum);
	switch(n)
	{
	case 0: //Copier
		n = ((InputBoxNum(CHOOSE_IMAGE, nMax) - 1) | 0xF00);
		break;
	case 1://Copier sur tous
		n = 0xFFF;
		break;
	case 2: //Inverser l'image
		{
			for(int y = y1; y <= y2; y++)
			{
				invhLine(x1, y, x2);
			}
		}
		break;
	case 3: //Effacer l'�cran
		{
			for(int y = y1; y <= y2; y++)
			{
				hLine(x1, y, x2, 0);
			}
		}
		break;
	case 4://Visualisation du menu
		{
			int i = 0;
			int nb = GetNbMenus(infos);
			int key;
			CopyPage(SEG4, SEG1);
			nShowTime = 0;//D�sactive l'affiche de l'heure et date
			do
			{
				my_movedata((__segment)menus, (unsigned)menus[i].menu, SEG1, 0, 1024, 0);
				key = ReadKey();
				if(key == K_DOWN)
					i++;
				if(key == K_UP)
					i += (nb - 1);
				i = i % nb;
				if(key == K_OPTN && (key = ShowInputPopup(msg_option_preview, 2)) != -1)
				{
					int r = InputBoxNum(MSG_IMAGE, 20);
					if(r > 0)
					{
						static char sFile[] = "PICT00";
						memory_zone bf; 
						char buffer[MAXCHIFFRE];
						CopyChar(sFile+4, convertNum(r, buffer, 0));			

						if(key == 0)
						{
							//Importer
							if(search_mem_zone(7, (unsigned char*)sFile, &bf) == 2061)
							{
								read_mem_zone(&bf, menus[i].menu, 0, 1024);
							}
						}
						else
						{
							//Exporter
							if(resize_mem_zone(7, sFile, 2061, &bf) != -1)
							{
								write_mem_zone(&bf, menus[i].menu, 0, 1024);
							}	
						}
					}
				}
			}while(key != K_ESC && key != K_EXE);
			CopyPage(SEG1, SEG4);
			nShowTime = options[2];//Restore les r�glages sur l'affichage de l'heure et la date
		}
	}
	return n;
}

void EditIcon(TInfo* infos, TMenu* menus)
{
	int num    = 0;
	int sel    = 0;
	int nStart = 0;
	int key;
	do
	{
		int nb      = GetNbIcons(infos);
		int nNbMenu = GetNbMenus(infos);
		num = num % nb;
		void* arg[]= {(void*)num, (void*)nb, infos[num].name, infos[num].image,
			infos[num].lecteur, infos[num].arg,
			infos[num].version, msg_yesno[infos[num].bmp == 2]};
		key = ShowMenuSelection(msg_systemmenu + 1, 6, nStart, sel, 8, EditIconDisplay, arg, IconExtraHandler, HEIGHT_SPACE);
		if(key == K_EXE) //Changer un parametre
		{
			switch(sel)
			{
			case 0://Nom
				InputBoxString(NAME, infos[num].name, 12, 0, MODE_MAJ, 0);
				break;
			case 1://BMP
				InputBoxString(BMP, infos[num].image, 12, 0, MODE_MAJ, 0);
				break;
			case 2://Chemin
				InputBoxString(PATH, infos[num].lecteur, 12, 0, MODE_MAJ, 0);
				break;
			case 3://Arguments
				InputBoxString(ARGUMENTS, infos[num].arg, 19, 0, MODE_MAJ, 0);
				break;
			case 4://Version
				InputBoxString(VERSION, infos[num].version, 4, 0, MODE_DIGIT, 0);
				break;
			case 5://Afficher/cacher dans system.exe
				ShowInSystem(infos, num, infos[num].bmp == 1);
			}
		}
		if(key == K_OPTN) //Options
		{
			switch(ShowInputPopup(msg_option_icon_editor, 2 + (num>0)))
			{
			case 0: //Ajouter icone
				num = AddIcon(infos, menus);
				break;
			case 1: //Editer l'icone
				{ 
					ShowTitleMenu(msg_option_icon_editor[1]);
					int nMin = GetFirstMenuOfIcon(num);
					int n = 0;
					int nMax = nMin + 2;
					while(nMax >= GetNbMenus(infos) || num < (nMax << 2)){
						nMax--;
					}
					int x = 44, y = 13;
					Rect(42, 11, 75, 33, 1);
					do
					{
						int nMenu = n + nMin;
						if(key == 0) //Val change
						{
							CopyIcon((__segment)menus, (unsigned)menus[nMenu].menu, num - 4 * nMenu, SEG1, 122, 2);
						}
						else
						{
							print2(2, 11, "%i/%i", n + 1, nMax - nMin + 1);
							CopyIcon(SEG1, 122, 2, (__segment)menus, (unsigned)menus[nMenu].menu, num - 4 * nMenu);
						}
						unsigned int cpt;
						key = EditImag(cpt, x, y, n, nMax - nMin + 1, 44, 13, 73, 31);
						if(key == K_OPTN)
						{
							int r = ShowEditorPopup(6, 44, 13, 73, 31, nMax - nMin + 1, infos, menus);
							if(r == 5)
							{
								//Inserer bordure
								hLine(45, 31, 73, 1);
								vLine(73, 14, 31, 1);
							}
							if(r & 0xF00)
							{
								r = r & 0xFF;
								for(key = 0; key <= nMax - nMin; key++)
								{
									if(key != n && (r == 0xFF || r == key))
									{
										CopyIcon((__segment)menus, (unsigned)menus[nMin + key].menu, num - 4 * (nMin + key), (__segment)menus, (unsigned)menus[nMin + n].menu, num - 4 * (nMin + n));
									}
								}
							}
							key = (r == 4);							
						}
					}while(key != K_ESC && key != K_EXE);
					key = 0;
				}
				break;
			case 2: //Decale l'icone a gauche
				{
					TInfo i;
					i = infos[num];
					i.number--;
					infos[num] = infos[num - 1];
					infos[num].number++;
					infos[num - 1] = i;
					ShowInSystem(infos, num, infos[num].bmp - 1);
					int n1 = GetFirstMenuOfIcon(num);
					int n2 = GetFirstMenuOfIcon(num - 1);
					int cpt = n1;
					if(n2 < n1)
					{
						CopyIcon((__segment)menus, (unsigned)menus[n2].menu, 11, (__segment)menus, (unsigned)menus[n1].menu, 8);
					}
					int a = num - (cpt << 2);
					while(cpt < nNbMenu && a > 0)
					{
						CopyIcon(SEG4, 0, 0, (__segment)menus, (unsigned)menus[cpt].menu, a);
						CopyIcon((__segment)menus, (unsigned)menus[cpt].menu, a, (__segment)menus, (unsigned)menus[cpt].menu, a - 1);
						CopyIcon((__segment)menus, (unsigned)menus[cpt].menu, a - 1, SEG4, 0, 0);
						cpt++;
						a -= 4;
					}
					if(cpt < nNbMenu && a <= 0)
					{
						CopyIcon((__segment)menus, (unsigned)menus[cpt].menu, 0, (__segment)menus, (unsigned)menus[cpt - 1].menu, 4);
					}
					num--;
				}
			}
		}
		if(key == K_DEL && AskConfirme())
		{	//Supprimer l'icone
			for(int n = num + 1; n < nb; n++)
			{
				infos[n - 1]		= infos[n];
				infos[n - 1].number = n - 1;
			}
			
			//Efface la zone d'infos
			infos[nb - 1].number = -1;
			infos[nb - 1].bmp	 = -1;
			
			nb--;
			n = GetFirstMenuOfIcon(num);
			
			//Decaler les icones.
			for(; n < nNbMenu; n++)
			{
				int nStart = num - 4 * n;
				if(nStart < 0)
				{
					nStart = 0;
				}
				for(int i = nStart; i < 11 && i < nb - 4 * n; i++)
				{
					CopyIcon((__segment)menus, (unsigned)menus[n].menu, i, (__segment)menus, (unsigned)menus[n].menu, i + 1);
				}
				if(n != nNbMenu - 1)
				{
					CopyIcon((__segment)menus, (unsigned)menus[n].menu, 11, (__segment)menus, (unsigned)menus[n + 1].menu, 8);
				}
				else
				{
					int xDest	= 30 * (i&3);
					int yDest	= 19 * (i >> 2);
					for(int x = 0; x < 30; x += 8)
					{
						for(int y = 7; y < 26; y++)
						{
							Byte((__segment)menus, (unsigned)menus[n].menu, x + xDest, y + yDest, 0, 0xFFFF);
						}
					}
				}
			}
		}//Fin de suppression d'une icone
		if(key == K_LEFT)
		{
			num += (nb - 1);
		}
		if(key == K_RIGHT)
		{
			num++;
		}
	}while(key != K_ESC);
}

int SendStart()
{
	int buf = 6;
	Send(&buf, 1);
	return (Receive(&buf, 1, 2000) != TIME_OUT);
}

int AskConfirme()
{
	return (!options[3] || MsgBox(1, SARE_YOU_SURE));
}

void ShowToolsMenu()
{
	int i = 0;
	int nStart = 0;
	int key;
	while(1)
	{
		key = ShowMenuSelection(msg_outilsmenu, 4, nStart, i, 2);
		if(key == K_ESC)
		{
			return;
		}
		if(i == 3) //Rebooter
		{
			rebootcalc();
		}
		if(i == 1)//Gestionnaire de flash
		{   
			ShowFlashManager();
		}
		if(i == 0) //Gestionnaire de memoire
		{
			ShowRAMManager();
		}
		if(i == 2) //Editer le systeme
		{		
			ShowEditSystemMenu();
		}              
	}
}

void ShowOptionsMenu()
{
	int i      = 0;
	int nStart = 0;
	int key;
	void* arg[5];
	do
	{
		arg[0] = (void*)nSpeeds[options[0]];
		arg[1] = sReboot[options[1]];
		arg[2] = sDisplay[options[2]];
		arg[3] = msg_yesno[options[3]];
		arg[4] = msg_yesno[options[4]];
		key = ShowMenuSelection(msg_mainmenu+4, 5, nStart, i, 8, OptionDisplay, arg);
		if(key == K_LEFT)
		{
			options[i] = (options[i] + max_options[i] - 1) % max_options[i];
		}
		if(key == K_RIGHT)
		{
			options[i] = (options[i] + 1) % max_options[i];
		}
	}while(key != K_ESC);
}

void ShowEditSystemMenu()
{
	TInfo infos[35];
	TMenu menus[7];
	ReadMenu(infos, menus); 
	ShowEditSystemMenu(infos, menus, 5);
}

void ShowEditSystemMenu(TInfo* infos, TMenu* menus, int nNbItem)
{
	memory_zone bf;
	int i = 0;
	int nStart = 0;
	int key;
	while(1)
	{
		key = ShowMenuSelection(msg_systemmenu, nNbItem, nStart, i, 2);
		if(key == K_ESC)
		{
			return;
		}
		if(i == 4) //Appliquer les changements
		{
			ShowProgressPopup(0, -1, WRITING_DATA);
			UpdateMenu(infos, menus);
			//Reboot la machine pour que les changements prennent effet
			rebootcalc();
		}
		if(i == 0) //Editer icones
		{
			EditIcon(infos, menus);
		}
		if(i == 2 || i == 3) //Charger/sauver Systeme
		{
			key = InputBoxNum(MSG_SYSTEM, 9);
			if(key != -1)
			{
				static char sFile[] = "SYSTEM0";
				sFile[6] = key + '0';
				if(i == 2)
				{
					//Charger
					if(search_mem_zone(3, (unsigned char*)sFile, &bf) == 9492)
					{
						/* ATTENTION CODE PAS TRES BEAU MAIS PERMET D'EVITER UN APPEL DE FONCTION */
						/* NE PAS CHANGER L'ORDRE DE DECLARATION DES VAR INFOS ET MENUS */
						read_mem_zone(&bf, menus, 0, 9478);
					}
					else
					{
						MsgBox(0, SYSTEM_NOT_FOUND_OR_NOT_VALID);
					}
				}
				else
				{
					//Sauver
					if(resize_mem_zone(3, sFile, 9492, &bf) != -1)
					{		
						/* ATTENTION CODE PAS TRES BEAU MAIS PERMET D'EVITER UN APPEL DE FONCTION */
						/* NE PAS CHANGER L'ORDRE DE DECLARATION DES VAR INFOS ET MENUS */
						write_mem_zone(&bf, menus, 0, 9478);
					}
				}
			}
		}
		if(i == 1) //Editer le titre d'un menu
		{
			ShowTitleMenu(msg_systemmenu[2]);
			int n = 0;
			int nb = GetNbMenus(infos);
						
			int x = 0;
			int y = 27;
			hLine(0, 26, 127, 1);
			hLine(0, 34, 127, 1);
			do
			{
				if(key == 0) //Val change
				{
					CopyTitle((__segment)menus, GETOFFSETMENU(n), SEG1, 30);
				}
				else
				{
					print2(2, 25 - HEIGHT_SPACE, MENU, n + 1, nb);
					CopyTitle(SEG1, 30, (__segment)menus,GETOFFSETMENU(n));
				}
				unsigned int cpt;
				key = EditImag(cpt, x, y, n, nb, 0, 27, 127, 33);
				if(key == K_OPTN)
				{
					int r = ShowEditorPopup(5, 0, 27, 127, 33, nb, infos, menus);
					if(r & 0xF00)
					{
						r = r & 0xFF;
						for(key = 0; key < nb; key++)
						{
							if(key != n && (r == 0xFF || r == key))
							{
								CopyTitle((__segment)menus, GETOFFSETMENU(key), (__segment)menus, GETOFFSETMENU(n));
							}
						}
					}
					key = (r == 4);
				}
			}while(key != K_ESC && key != K_EXE);
		}
	}
}

void ShowSendMenu()
{
	switch(ShowInputPopup(msg_sendmenu, 3))
	{
	case 0:
		ShowSendFlashMenu();
		break;
	case 1:
		ShowSendRAMMenu();
		break;
	case 2:
		OnRemoteSystem();
		break;
	}
}                                         

void OnReceiveMode()
{
	int n;
	unsigned int nSize;
	THeader header;
	InitComm(PR_GCOMM);

	while(1)
	{
		ShowProgressPopup(1, -1, WAITING_REQUEST);
		do{
			if(ReadKey() == K_ESC)
			{
				CloseBox();
				CloseComm();
				return;
			}
			n = ReceivePacket(&header, sizeof(header), 180); // Recoit le type d'objet
		}while(n != sizeof(header));
		
		CloseBox();

		if(header.type == TRANSFERT_EXIT) //Arreter la communication
		{
			CloseComm();
			return;
		}
		if(header.type == TRANSFERT_GETSIZE) //Retourner la taille totale des lecteurs demandes
		{
			nSize = 0;
			for(n = 0; n < 7; n++)
			{
				if(header.size & (1 << n))
				{
					nSize += GetSizeUseful(n);
				}
			}
			SendPacket(&nSize, sizeof(n), 500);
		}
		if(header.type == TRANSFERT_EXPORTDRIVE) //Exporter un lecteur de la Flash
		{
			if(ExportDrive(header.name[0], header.name[0], PR_GCOMM) < 0)
			{
				ErrorComm();
				return;
			}
		}
		if(header.type == TRANSFERT_IMPORTDRIVE) //Importer un lecteur de la Flash
		{
			if(ImportDrive(header.name[0], header.size) < 1)
			{
				ErrorComm();
				return;
			}
			if(nReboot != 2)
			{
				nReboot = 1 + (header.name[0] == 0);
			}
		}
		if(header.type & TRANSFERT_RAMFILE) //recevoir un fichier et le mettre dans la RAM (fichiers BASIC, ...)
		{
			nSize = header.size;
			unsigned int nRealsize = nSize + 14;
			int numzone = header.type & 15;  
			memory_zone bf;
			if(numzone == 1){
				nRealsize += 10;
			}
			if(numzone)
			{
				if(search_mem_zone(numzone, (unsigned char*)header.name, &bf) != -1)
				{
					if(MsgBox(1, REPLACEQ, header.name) == 0)
					{
						header.type = TRANSFERT_STOP;
						SendPacket(&header, sizeof(header), 700);
						continue;
					}
				}
				if(resize_mem_zone(numzone, header.name, nRealsize, &bf) == -1)
				{ 
					CloseComm();
					return;
				}
			}

			ShowProgressPopup(0, -1, sReceiving, header.name);

			DisableKeyboard(); //Desactive le clavier

			//Lancement du transfert du fichier
			header.type = TRANSFERT_GO;
			n = SendPacket(&header, sizeof(header), 700);
			if(numzone)
			{
				if(numzone == 1)//Reception du mdp si fichier basic
				{
					n = ReceivePacket(bf.b_segment, bf.b_offset + 8 + 3, 8, 2000);
				}
				while(n > 0 && nSize)
				{
					n = ReceivePacket(bf.b_segment, bf.b_inner_offset, nSize, 2000);
					bf.b_segment += (n >> 4);
					nSize -= n;
				}
			}
			else
			{
				char far* pAlpha = tell_mem_zone_seg(0);
				n = ReceivePacket(_FP_SEG(pAlpha), _FP_OFF(pAlpha), 504, 700);
			}
			EnableKeyboard();  
			CloseBox();
			if(n <= 0)
			{
				ErrorComm();
				return;
			}
		}
	}
}

void DeleteFile(TRAM& file)
{
	create_mem_zone(file.id, (unsigned char*)file.name, 0, DELETE_ZONE);
}

void ChangePassword(memory_zone& bf)
{       
	if(bf.b_ztype == 1)
	{
		InputBoxString(ENTERPASS, (char*)bf.b_password, 8, 0, MODE_MAJ, 0);
		change_password(&bf, bf.b_password);
	}
}

void ShowRAMManager()
{
	TRAM files[FILE_MAX];
	int nDoInit = 1;
	int start = 0;
	int choix = 0;
	int key;
	unsigned int n;
	int i;
	memory_zone bf;
	memory_zone bf2;
	do{
		if(nDoInit)
		{
			n = ExploreRAM(files, FILE_MAX);
			nDoInit = 0;
		}
	
		key = ShowRAMSelection(msg_outilsmenu+1, files, choix, start, n, HEIGHT_SPACE, RAMManagerExtraHandler);

		if(key == K_DEL && n && AskConfirme())
		{
			for(i = 0; i < n; i++)
			{
				if(files[i].sel)
				{
					DeleteFile(files[i]);
					nDoInit = 1;
				}
			}
			if(!nDoInit)
			{
				DeleteFile(files[choix]);
				nDoInit = 1;
			}
			for(i = HEIGHT_SPACE; i < m_nYMax; i+=HEIGHT_SPACE)
			{
				ClearLine(i);
			}
		}
		if(key == K_EXE)
		{
			int j = 2;//Creer un fichier si pas de fichier selectionne
			if(n)
			{
				j = ShowInputPopup(msg_option_memory_manager, 4 + (files[choix].id == 1));
				search_mem_zone(files[choix].id, (unsigned char*)files[choix].name, &bf);
			}
			char buffer[9];
			buffer[0] = '\0';
			if(j == 3)//Redimmensionner
			{
				long n = InputBoxNum(SIZEQ, 65535);
				if(n != -1)
				{
					resize_mem_zone(files[choix].id, files[choix].name, n, &bf);
				}
	        }
	        switch(j)
	        {
			case 0://Renommer le nom du fichier
				CopyChar(buffer, files[choix].name);
			case 1://Copier un fichier
			case 2://Creer un nouveau fichier
				if(InputBoxString(MSG_ENTERNAME, buffer, 8, 0, MODE_MAJ, 0))
				{
					int id = -1;
					unsigned short nSize;
					if(j == 2)
					{
						long n = InputBoxNum(SIZEQ, 65535);
						if(n != -1)
						{
							id = ShowInputPopup(sZoneName, NUMZONE_CREATED) + 1;
							nSize = n;
						}
					}
					else
					{
						id    = files[choix].id;
						nSize = bf.b_size;
					}
					if(id > 0 && resize_mem_zone(id, buffer, nSize, &bf) != -1)
					{
						nDoInit = 1;
						if(j != 2) //Copie les donnees
						{
							for(i = 0; buffer[i] != '\0' && buffer[i] == files[choix].name[i]; i++);
							if(buffer[i] == files[choix].name[i])
							{
								break;
							}
							search_mem_zone(id, (unsigned char*)files[choix].name, &bf2);
							my_movedata(bf2.b_segment, bf2.b_inner_offset, bf.b_segment, bf.b_inner_offset, bf2.b_real_size, 0);
							//Copie le mot de passe
							change_password(&bf, bf2.b_password);
							if(j == 0)//Supprime le fichier de depart
							{
								DeleteFile(files[choix]);
								break;
							}
						}
						ChangePassword(bf);
					}
				}
				break;
			case 4:
				ChangePassword(bf);
				break;
			}			
		}
	}while(key != K_ESC);
}                                     

void ShowSendFlashMenu()
{
	int i;    
	int key;
	char drives[7]; //Lecteur associe au lecteur selectionne
	char sel[7]; 
	init_area((__segment)sel, (unsigned)sel, sizeof(sel), 0, 0);
	i = 0;
	int nStart = 0;
	void* arg[2] = {sel, drives};
	do
	{
		key = ShowMenuSelection(msg_sendmenu, 7, nStart, i, 8, &FlashDisplay, arg);

		if(key == K_F1)
		{
			sel[i]   ^= 1;
			drives[i] = i;
		}
		if(key == K_LEFT && drives[i])
		{
			drives[i]--;
		}
		if(key == K_RIGHT && drives[i] < 6)
		{
			drives[i]++;
		}
		if(key == K_EXE) //Envoyer les lecteurs selectionnes
		{
			for(key = 0; key < 7 && !sel[key]; key++);
			if(key == 7)
			{
				sel[i]    = 1;
				drives[i] = i;
			}
			int nProtocol = ShowInputPopup(msg_protocol, 2);
			if(nProtocol != -1)
			{	
				key = InitComm((PROTOCOL)nProtocol);
	
				for(int j = 0; key > 0 && j < 7; j++)
				{
					if(sel[j])
					{
						key = key && (ExportDrive(drives[j], j, (PROTOCOL)nProtocol) > 0);
					}
				}
				EndTransfert((PROTOCOL)nProtocol, key);
			}
		}                      
	}while(key != K_ESC);
}     
   
void OnRemoteSystem()
{
	int nDrive;
	int nFile;
	TInfo infos[35];
	TMenu menus[7];
	memory_zone bf[3];
	static char sFilename[] = "TMP";
	for(nDrive = 7; nDrive > 0 && GetSizeUseful(nDrive); nDrive--);
	
	if(nDrive == 0)
	{
		MsgBox(0, SNEED_ONE_FREE_DRIVE);
		return;
	}
	unsigned int size = 39688;
	for(nFile = 3; nFile <= 5; nFile++)
	{
		if(resize_mem_zone(nFile, sFilename, size, bf + nFile - 3) == -1)
		{
			return;
		}
		size = 32783;//32768+14 +1 pour le dernier
	}				
	//Recevoir le systeme de la G100 'vierge' (celle dont on veut lui editer son menu)
	//Pour cela, sauve le systeme dans le lecteur libre trouve
	ShowProgressPopup(0, -1, sReceiving, sDrives[0]);
	int ok = InitComm(PR_G100);
	SendForCasio(importdrive, 40);
	ok = ok && (Receive(SEG4, 0, 40, 2000) > 0) && SendStart()
			&& Receive(bf[0].b_segment, bf[0].b_inner_offset, 16384, 1000) > 0 //16384 0xFF
			&& Receive(infos, sizeof(infos), 1000) > 0 //zone info
			&& Receive(bf[0].b_segment, bf[0].b_inner_offset, 5882, 1000) > 0
			&& Receive(menus, sizeof(menus), 1000) > 0
			&& Receive(bf[0].b_segment + 320, bf[0].b_inner_offset + 762, 33792, 1000) > 0
			&& Receive(bf[1].b_segment, bf[1].b_inner_offset, 32768, 1000) > 0  //Lecteur A
			&& Receive(bf[2].b_segment, bf[2].b_inner_offset, 32769, 1000) > 0; //Lecteur A 
	CloseBox();
	if(ok)
	{
		//Editer le menu recu
		ShowEditSystemMenu(infos, menus, 4);
					
		MAPPER_EN_4000(nDrive);
		//Ecrire les infos sur les icones (35 * 66 octets)
		WriteInFlash(0x4000, 0x4000, (__segment)infos, (unsigned)infos, 2310);
		WriteInFlash(0x4000, 18694, bf[0].b_segment, bf[0].b_inner_offset, 5882);
		//Ecrire les nouveaux menus (7 * 1024 octets)
		WriteInFlash(0x4000, 0x6000, (__segment)menus, (unsigned)menus, 7168);
		WriteInFlash(0x4000, 31744, bf[0].b_segment+320, bf[0].b_inner_offset + 762, 33792);
		//Ecrit le lecteur A:
		WriteInFlash(0x5000, 0, bf[1].b_segment, bf[1].b_inner_offset, 32768);
		WriteInFlash(0x5800, 0, bf[2].b_segment, bf[2].b_inner_offset, 32768);
					
		//Envoi le menu edit� dans la G100 'vierge'
		ok = ExportDrive(0, nDrive, PR_G100);

		//Formate le lecteur qui a recu le systeme
		EraseDrive(nDrive);
	}
					
	//Ferme la communication
	EndTransfert(PR_G100, ok);

	//Supprime les fichiers temporaires
	for(nFile = 3; nFile <= 5; nFile++)
	{
		create_mem_zone(nFile, (unsigned char*)sFilename, 0, DELETE_ZONE);
	}
}

void ShowSendRAMMenu()
{	
	TRAM files[FILE_MAX];
	int start = 0;
	int choix = 0; 
	int key;
	memory_zone bf;
	unsigned int n = ExploreRAM(files, FILE_MAX);
	THeader header;
	if(n < FILE_MAX)
	{
		CopyChar(files[n].name, "VARIABLE");
		n++;
	}
	do
	{		
		key = ShowRAMSelection(msg_sendmenu+1, files, choix, start, n, 0);

		if(key == K_EXE)
		{
			unsigned long totalsize = 0, total = 0;
			unsigned int size;
			for(int i = 0; i < n; i++)
			{
				if(files[i].sel)
				{
					if(files[i].id)
					{
						//Ne v�rifie pas si search_mem_zone �choue car les fichiers affich�s sont sens�s �tre valides
						totalsize += search_mem_zone(files[i].id, (unsigned char*)files[i].name, &bf);
					}
					else
					{
						totalsize += 504;
					}
				}
			}
			if(totalsize)
			{
				InitComm(PR_GCOMM);
				for(i = 0; i < n && key > 0; i++)
				{
					if(files[i].sel)
					{
						header.type = TRANSFERT_RAMFILE + files[i].id; //Envoi un fichier dans la ram
						CopyChar(header.name, files[i].name);  
						
						ShowProgressPopup(1, (total*100)/totalsize, sSending, header.name);

						size = 504;//Taille de "VARIABLE"
						if(files[i].id)
						{
							//Ne v�rifie pas si search_mem_zone �choue car les fichiers affich�s sont sens�s �tre valides
							search_mem_zone(files[i].id, (unsigned char*)files[i].name, &bf);
							size = bf.b_real_size;
							//Enl�ve la diff�rence
							total += (bf.b_size - size);
						}
						 
						//Sp�cifie la taille des donn�es � envoyer (hors en-t�te)       
						header.size = size;
	                    
						key = SendPacket(&header, sizeof(header), 700);
	                    
	                    //Attend la confirmation
						while(key > 0 && ReceivePacket(&header, sizeof(header), 100) == GLINK_TIMEOUT)
						{
							if(ReadKey() == K_ESC)
							{
								key = -1;
							}
						}
						total += size;
						if(key > 0 && header.type == TRANSFERT_GO)
						{
							if(files[i].id == 1)
							{
								key = SendPacket(bf.b_password, 8, 700);
							}
							if(files[i].id)
							{
								int nRead = GCOMM_SENDRAM_PACKETSIZE;
								while(size && key > 0)
								{
									if(size < nRead)
									{
										nRead = size;
									}
									key    = SendPacket(bf.b_segment, bf.b_inner_offset, nRead, 700);
									size  -= nRead;
									bf.b_segment += (GCOMM_SENDRAM_PACKETSIZE >> 4);//Incr�mente le segment au lieu de l'offset pour eviter une erreur si la taille du fichier est proche de 65535
									ShowProgressPopup(1, ((total-size)*100)/totalsize, 0);
								}
							}
							else
							{  
								char far* pAlpha = tell_mem_zone_seg(0);
								key = SendPacket(_FP_SEG(pAlpha), _FP_OFF(pAlpha), 504, 700);
							}
						}
						CloseBox();
						if(ReadKey() == K_ESC)
						{
							break;
						}
					}//if(sel[i])
				}//for all files
				EndTransfert(PR_GCOMM, key);
			}//if(totalsize)
		}//if(key == K_EXE)
	}while(key != K_ESC);
}

#define LCD_WIDTH 3

void DrawLCDNumber(int right, int bottom, int nHeight, int num)
{
	static unsigned char numbers[] = {1 | 2 | 4 | 8 | 16 | 64,//0
									1 | 2,                    //1
									2 | 8 | 16 | 32 | 64,     //2
									1 | 2 | 16 | 32 | 64,     //3
									1 | 2 |  4 | 32,          //4   
									1 | 4 | 16 | 32 | 64,     //5
									1 | 4 |  8 | 16 | 32 | 64,//6
									1 | 2 | 16,               //7
									127,                      //8
									1 | 2 |  4 | 16 | 32 | 64,//9
									}; 
	int nStep = nHeight + LCD_WIDTH;
	static char X[] = {1, 1, 0, 0};
	static char Y[] = {0, 1, 1, 0, 2, 1, 0};   
	static char V[7][LCD_WIDTH] = {{-1, 0, 1}, { 0, 1, 2}, {2, 1,  0}, {1, 0, -1}, {0, 1, 2}, {1, 2, 1}, {2, 1, 0}};
	static char D[4][LCD_WIDTH] = {{ 0, 1, 2}, {-1, 0, 1}, {1, 0, -1}, {2, 1,  0}};
	int i;    
	for(int cpt= 0; cpt < 2; cpt++)
	{
		int n = num % 10;
		num /= 10;
		for(i = 0; i < 4; i++)
		{
			for(int w = 0; w < LCD_WIDTH; w++)
			{
				vLine(X[i] * nStep + w + right,
					bottom - Y[i] * nStep - nHeight - LCD_WIDTH + 1 - V[i][w],
					bottom - Y[i] * nStep - LCD_WIDTH + D[i][w], numbers[n]&(1<<i));
			}
		}
		for(; i < 7; i++)
		{
			for(int h = 0; h < LCD_WIDTH; h++)
			{
				hLine(LCD_WIDTH + right - V[i][h], bottom - Y[i] * nStep - h,
					  LCD_WIDTH + right + nHeight - 1 + V[i][h], numbers[n]&(1<<i));
			}
		}
		right -= (nHeight +  2 * LCD_WIDTH+2);
	}	
}
 
void DrawClockBouton(int x, char c)
{
	int y = 63 - HEIGHT;
	putchar2(x + ((16 - WIDTH) >> 1), y, c);
	for(; y < 64; y++){
		invhLine(x, y, x + 15);
	}
}

void ShowClock()
{
#define CLOCK_HEIGHT     12
#define CLOCK_SEC_HEIGHT  8

	int nY = ((64 - (CLOCK_HEIGHT * 2 +  LCD_WIDTH * 3)) >> 1)
				+ CLOCK_HEIGHT * 2 +  LCD_WIDTH * 3 - 1;

	static unsigned char point_sprite[] = {96, 240, 240, 96};
	
	nShowTime = 0;//Efface tout l'�cran
	ShowTitleMenu(msg_mainmenu[5]);
	nShowTime = 2;//Affiche que la date en bas de l'�cran

	DrawSprite(2*(CLOCK_HEIGHT + 2 * LCD_WIDTH + 2) + 5, nY - ((CLOCK_HEIGHT + LCD_WIDTH*2 - 4) >> 1) - 3, point_sprite, 240, 4);
	DrawSprite(2*(CLOCK_HEIGHT + 2 * LCD_WIDTH + 2) + 5, nY - ((CLOCK_HEIGHT + LCD_WIDTH*2 - 4) >> 1) - 3 - CLOCK_HEIGHT - LCD_WIDTH, point_sprite, 240, 4);
	
	DrawClockBouton( 94, 'H');
	DrawClockBouton(111, 'D'); 

	int key;
	do
	{
		int min, sec;
		asm in  ax, 0x1E;
		asm mov min, ax;
		asm in  ax, 0x1D;
		asm mov sec, ax;
		
		DrawLCDNumber(CLOCK_HEIGHT + 2 * LCD_WIDTH + 2 + 5, nY, CLOCK_HEIGHT, min>>8);
		DrawLCDNumber(3*(CLOCK_HEIGHT + 2 * LCD_WIDTH + 2) + 5 + 6, nY, CLOCK_HEIGHT, min&0xFF);
		DrawLCDNumber(4*(CLOCK_HEIGHT + 2 * LCD_WIDTH + 2) + 5 + 6 + 2 + (CLOCK_SEC_HEIGHT + 2 * LCD_WIDTH + 2),
						 nY, CLOCK_SEC_HEIGHT, sec&0xFF);
						 
		asm hlt;
		asm hlt;
		asm hlt;
		asm hlt;
		key = ReadKey();
		
		if(key == K_F5) //Reglage de l'heure
		{
			int h, m;
			h = InputBoxNum(HOURQ, 23);
			if(h != -1)
			{
				m = InputBoxNum(MINUTEQ, 59);
				if(m != -1)
				{
					asm mov ax, h;
					asm shl ax, 8;
					asm add ax, m;
					asm out 0x1E, ax;
					asm mov al, 3;
					asm out 0x1D, al;
				}
			}
		}
		if(key == K_F6) //Reglage de la date
		{
			int y = InputBoxNum(YEARQ, 2179);
			if(y >= 2000)
			{
				int m = InputBoxNum(MONTHQ, 12) - 1;
				if(m >= 0)
				{
					int d = InputBoxNum(DAYQ, month_day_table[m]);
					if(d > 0)
					{
						day_time.year	= y;
						day_time.month	= m;
						day_time.day	= d;
						make_a_date(&day_time, 1);
						asm mov ax, day_time.day_number;
						asm out 0x20, ax;
						asm mov al, 4;
						asm out 0x1D, al;
					}
				}
			}
		}
	}while(key != K_ESC);
}

int DriveState(int nDrive)
{
	static unsigned char headers[3][8] = {
		{0xEB, 0x28, 0x90, 0x44, 0x4C, 0x52, 0x44, 0x49},//Rom-Disk	
		{0x00, 0xFF, 0x50, 0x72, 0x6F, 0x67, 0x72, 0x61},//BASIC     
		{0x00, 0xFF, 0x42, 0x61, 0x63, 0x6B, 0x75, 0x70},//Backup
	};

	MAPPER_EN_6000(nDrive);
	unsigned char far* pDrive = (unsigned char far*)MK_FP(0x6000, 0);

	for(int nType = 0; nType < 3; nType++)
	{
		for(int i = 0; i < 8 && headers[nType][i] == pDrive[i]; i++);
		if(i == 8){
			return nType + DRV_ROMDISK;
		}
	}
	return GetSizeUseful(nDrive) != 0;
}

void ShowFlashManager()
{
	int choix  = 0; 
	int start = 0;  
	char drives_state[7]; 
	int key;
	for(key = 0; key < 7; key++)
	{
		drives_state[key] = DriveState(key);
	}
		
	while(1)
	{
		key = ShowMenuSelection(msg_outilsmenu + 2, 7, start, choix, 2, FlashManagerDisplay, (void**)drives_state);
		if(key != K_EXE)
		{
			break;
		}
		switch(ShowInputPopup(msg_option_flash_manager, 1 + (choix != 0)))
		{
		case 1: //Formater
			if(AskConfirme())
			{
				EraseDrive(choix);
				drives_state[choix] = DRV_EMPTY;
			}
			break;
		case 0: //Copier
			{
				char* pDrives[6];
				key = 0;		
				for(int i = 0; i < 7; i++)
				{
					if(i != choix)
					{
						pDrives[key] = sDrives[i];
						key++;
					}
				}
				key = ShowInputPopup(pDrives, 6);
				if(key != -1)
				{
					if(key >= choix)
					{
						key++;
					}
					//Copie les deux lecteurs
										
					//Formatage du lecteur destinataire
					EraseDrive(key);
										
					//Mappage du lecteur source en 0x4000
					MAPPER_EN_4000(choix);
										
					//Mappage du lecteur destinataire en 0x6000.
					MAPPER_EN_6000(key);
										
					//Copie les donnees
					ShowProgressPopup(0, -1, WRITING_DATA);
					WriteInFlash(0x6000, 0, 0x4000, 0, 0);
					WriteInFlash(0x7000, 0, 0x5000, 0, 0);
					CloseBox();
					drives_state[key] =	drives_state[choix];
				}
			}
			break;
		}
	}
}   

int resize_mem_zone(unsigned int zone_id, const char* zonename, unsigned int size, struct memory_zone* bf)
{
	if(create_mem_zone(zone_id, (unsigned char*)zonename, size, RESIZE_ZONE) >= 0)
	{        
		search_mem_zone(zone_id, (unsigned char*)zonename, bf);
		return 1;
	}
	MsgBox(0, ERROR_ON_FILE, zonename); 
	return -1;
} 
