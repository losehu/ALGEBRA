
#ifndef _GCOMM_H_
#define _GCOMM_H_ 

#define FILE_MAX 350
/** Structure pour stocker des informations sur les fichiers memzone */
struct TRAM
{
	char name[12];//Nom du fichier
	short sel;    //Zero si le fichier n'est pas s�lectionn�   
	short id;     //Id du fichier
};


//Structure des icones du systeme
struct TInfo
{
	char number;
	char bmp;
	char version[5];
	char name[13];
	char lecteur[13];
	char image[13];
	char arg[20];
};

struct TMenu
{
	unsigned char menu[1024];
};

//Protocole GComm
#define TRANSFERT_RAMFILE		128
#define TRANSFERT_GO			2
#define TRANSFERT_STOP			3
#define TRANSFERT_WAIT			4
#define TRANSFERT_IMPORTDRIVE	5
#define TRANSFERT_EXPORTDRIVE	6
#define TRANSFERT_GETSIZE		7
#define TRANSFERT_EXIT			50


struct THeader
{
	unsigned char type;
	char name[9];
	unsigned short size;
};

//Liste des protocoles
enum PROTOCOL{
	PR_GCOMM = 0,
	PR_G100,
};
/** Type d'Handler pour afficher une ligne d'un menu */
typedef void (*DisplayHandler)(int, int, void**); 
/** Type d'Handler pour afficher quelque chose de particulier dans un menu */
typedef void (*ExtraHandler)(void**); 

/** Type de lecteur retourn� par DriveState */
enum TDRIVE{
	DRV_EMPTY   = 0,
	DRV_UNKNOW  = 1,
	DRV_ROMDISK = 2,
	DRV_BASIC   = 3,
	DRV_BACKUP  = 4
	};

void EnableKeyboard();
void DisableKeyboard();
int  WaitKey();
void Delay(unsigned int time);
int  ReadKey();
int  ExportDrive(int nDrive, int nSourceDrive, PROTOCOL nProtocol);
int  ImportDrive(int nDrive, int nNbSeg);
unsigned int UsedArea(unsigned int nSegment, unsigned int nSize);
unsigned int EraseDrive(int nDrive);
void         EraseSegment(unsigned int nSegment);
unsigned int GetSizeUseful(int nDrive);//Taille en segment (octet divis� par 16)
void ReadMenu(TInfo* infos, TMenu* menus);
int  GetNbIcons(TInfo* infos);
int  GetNbMenus(TInfo* infos);
int  AddIcon(TInfo* infos, TMenu* menus);
void UpdateMenu(TInfo* infos, TMenu* menus);
void WriteInFlash(unsigned int nSegment, unsigned int nOffset, unsigned int nSegSource, unsigned int nOffsetSource, unsigned int nSize);
void CopyTitle(unsigned int nSegment, unsigned int nOffset, unsigned int nSegSource, unsigned int nOffsetSource);
void ShowInSystem(TInfo* infos, int n, int show);
void SendForCasio(const void* buffer, unsigned int nSize);
void InvertLine(int k);
void ShowTitleMenu(const char* title);
void ClearLine(int l);
void rebootcalc();
unsigned int ExploreRAM(TRAM* files, unsigned int nMax);
int ShowRAMSelection(char** msg, TRAM* files, int& choix, int& start, int n, int nRemoveRow, ExtraHandler extra = NULL);
int ShowMenuSelection(char** msg, int nLine, int& nStart, int& nChoix, int nMaxStopKeys, DisplayHandler handler = NULL, void** arg = NULL, ExtraHandler extra = NULL, int nRemoveRow = 0);
int EditImag(unsigned int & cpt, int& x, int& y, int& n, int nb, int left, int top, int maxX, int maxY);
void CopyIcon(unsigned int nSegDest, unsigned int nOffsetDest, int nDest, unsigned int nSegSource, unsigned int nOffsetSource, int nSource);
int Byte(unsigned int nSeg, unsigned int nOffset, int x, int y, unsigned int val, unsigned int mask);
int GetFirstMenuOfIcon(int num);
int ShowEditorPopup(int nNum, int x1, int y1, int x2, int y2, int nMax, TInfo* infos, TMenu* menus);
void EditIcon(TInfo* infos, TMenu* menus);
int SendStart();
int AskConfirme(); 

void ErrorComm();
void CloseComm();
int  InitComm(PROTOCOL nProtocol);
void EndTransfert(PROTOCOL nProtocol, int nStatus);
void Quitter();

void ShowToolsMenu();
void ShowOptionsMenu();  
void ShowEditSystemMenu(TInfo* infos, TMenu* menus, int nNbItem);
void ShowEditSystemMenu();
void ShowSendMenu();
void ShowRAMManager();
void ShowFlashManager();
void ShowSendFlashMenu();
void ShowSendRAMMenu();
void ShowClock();

void OnReceiveMode();
void OnRemoteSystem();

int  DriveState(int nDrive);
int  resize_mem_zone(unsigned int zone_id, const char* zonename, unsigned int size, struct memory_zone* bf);
void DeleteFile(TRAM& file);
void ChangePassword(memory_zone& bf);

#endif
