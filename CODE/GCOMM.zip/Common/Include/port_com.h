/************************************************************************
 *                                                                      *
 *                       PORT SERIE v1.00                               *
 *                                                                      *
 * Permet d'envoyer, recevoir des donn�es par le port s�rie.            *
 *                                                                      *
 * Auteur : dada66 (david.quaranta@laposte.net)                         *
 * (C) Copyright 2003-2004 Quaranta Software                            *
 ************************************************************************/

#ifndef PORT_COMM
#define PORT_COMM

#define TIME_OUT	-1

/** Macros permettant de d�sactiver et d'activer le clavier.
 * D�sactivez le clavier lors de l'envoi de bcp de donn�es en m�me temps.
 * Permet un gain de temps. (Vous pouvez aussi d�sactiver l'int9)
 */
#define DISABLEKEYBOARD	asm in al, 0x0A asm and al, 0xF7 asm out 0x0A, al
#define ENABLEKEYBOARD	asm in al, 0x0A asm  or al, 0x08 asm out 0x0A, al
  
/** Allume le port de la G100
 * Vitesse : 0 =>   9600 bps
 * Vitesse : 1 =>  14400 bps
 * Vitesse : 2 =>  19200 bps
 * Vitesse : 3 =>  28800 bps
 * Vitesse : 4 =>  38400 bps
 * Vitesse : 5 =>  57600 bps
 * Vitesse : 6 =>  76800 bps
 * Vitesse : 7 => 115200 bps
 */
extern void InitPort(int vitesse);

/** Ferme le port de communication */
extern __inline void ClosePort();

/** Envoi des donn�es */
extern __inline void Send(const void* buffer, unsigned int nSize);
extern void Send(unsigned int nSegment, unsigned int off_set, unsigned int nSize);

/** Retourne 1 en cas de succes, sinon une valeur negative
 * Pour le moment juste TIME_OUT
 * Time_out: Valeur max d'attente d'un octet, si le delai est depasse
 * Receive retourne TIME_OUT. La valeur 500 correspond � 1 seconde.
 */
extern int Receive(unsigned int nSegment, unsigned int off_set, unsigned int nSize, unsigned int time_out);
extern __inline int Receive(void* buffer, unsigned int nSize, unsigned int time_out);

#endif
