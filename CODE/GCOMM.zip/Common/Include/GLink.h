/************************************************************************
 *                                                                      *
 *                       GLINK Version 1.10                             *
 *                                                                      *
 * Permet d'envoyer ou recevoir des donn�es par le port s�rie,          *
 * en sachant si les donn�es sont vraiment bien arriv�es. (V�rification *
 * faites par checksum et accus� de rec�ption.                          *
 * Au niveau performance la perte reste minime.                         *
 *                                                                      *
 * Auteur : dada66 (david.quaranta@laposte.net)                         *
 * (C) Copyright 2003-2004 Quaranta Software                            *
 ************************************************************************/
             
#ifndef GLINK
#define GLINK

#define PACKETSIZE      1024 //Taille maximale recommand�e pour un packet
#define MAX_PACKETSIZE 32767 //Taille maximale envoy�e ou recue par SendPacket et ReceivePacket

/** Valeur retourn�e par SendPacket en cas de succes */
#define GLINK_OK 2

/** Valeurs retourn�es par SendPacket et ReceivePacket en cas d'erreur */
#define GLINK_TIMEOUT      -1 //Temps d'attente �coul�
#define GLINK_HEADER_ERROR -2 //La r�ponse du destinataire n'est pas correcte
#define GLINK_ARQ_TIMEOUT  -3 //Temps d'attente de l'accus� de r�ception d�pass�
#define GLINK_ARQ_ERROR    -4 //La valeur recue pour l'accus� de r�ception est mauvaise
#define GLINK_MAX_RESEND   -5 //Le nombre maximal de renvoi du packet a �t� atteint
#define GLINK_BADSIZE      -6 //Valeur retourn�e par SendPacket pour signaler un taille trop grande (ie. > MAX_PACKETSIZE)


/** Envoi un packet lu par ReceivePacket
 * nSize doit �tre inf�rieur ou �gale MAX_PACKETSIZE
 * Retourne une valeur negative en cas d'erreur
 * Retourne GLINK_OK en cas de succes (valeur positive)
 */
extern int SendPacket(unsigned int nSegment, unsigned int off_set, unsigned int nSize, unsigned int time_out);
extern int SendPacket(void* buf, unsigned int nSize, unsigned int time_out);

/** Recoit un packet envoye par SendPacket
 * Retourne une valeur negative en cas d'erreur
 * Retourne une valeur positive en cas de succes, la taille du packet recu,
 * sachant que cette taille ne depasse pas la valeur de nMaxSize
 */
extern int ReceivePacket(unsigned int nSegment, unsigned int off_set, unsigned int nMaxSize, unsigned int time_out);
extern int ReceivePacket(void* buffer, unsigned int nMaxSize, unsigned int time_out);

#endif
