/************************************************************************
 *                                                                      *
 *                       DadaAscii Version 1.20                         *
 *                                                                      *
 * Permet d'�crire du texte sur l'�cran de votre Graph100               *
 *                                                                      *
 * Auteur : dada66 (david.quaranta@laposte.net)                         *
 * (C) Copyright 2003-2004 Quaranta Software                            *
 ************************************************************************/


#ifndef DADA_ASCII_H
#define DADA_ASCII_H  

#include <graphic.h>
#ifdef GREY_MODE
#define COLORPARAMDEF , short nFlag = SPRITE_BW
#define COLORPARAM    , short nFlag
#define COLORFLAG     , nFlag 
#define COLORPARAMSIZE 1
#else
#define COLORPARAMDEF
#define COLORPARAM
#define COLORFLAG
#define COLORPARAMSIZE 0
#endif           

extern unsigned WIDTH; //Largeur de la police
extern unsigned HEIGHT;// hauteur de la police sans espace
extern unsigned WIDTH_SPACE; 
extern unsigned HEIGHT_SPACE; 

#define MAXCHAR      (128 / WIDTH_SPACE) // nbre de lettre max dans le sens horizontal
#define MAXROW       (64  / HEIGHT_SPACE)
#define MAXINDEXCHIFFRE			11
#define MAXCHIFFRE				MAXINDEXCHIFFRE + 1
#define CURSEUR_INSERT			1
#define CURSEUR_OVR				95
#define CURSEUR_SHIFT			2
#define CURSEUR_ALPHA_MAX_OVR	3
#define CURSEUR_ALPHA_MIN_OVR	4
#define CURSEUR_ALPHA_MAX_INS	5
#define CURSEUR_ALPHA_MIN_INS	6


enum TEXTALIGN{
	TEXT_LEFT = 0,
	TEXT_RIGHT,
	TEXT_CENTER,
	};

/** D�fini la police */
extern void setFont(void far* ascii, unsigned width, unsigned height);

/** si nWarp == 0, alors le texte est coup�
 *  si nWarp == 1 print va automatiquement � la ligne pour afficher tout le texte
 */
extern void setWordWrap(int nWrap);

/** Affiche un caract�re 
 * V�rifie les positions x et y
 * Ne v�rifie pas la validit� du caract�re lettre (ie > 128 si ASCII ou 256 pour Casio)
 * nFlag de DrawSprite (par d�faut SPRITE_BW permet un affichage en N&B)
 */
extern void putchar2(unsigned short x, unsigned short y, unsigned short lettre COLORPARAMDEF);

/** Converti un entier 'num' en une chaine de caractere
 * buf pointeur sur un tableau allou� de taille min MAXCHIFFRE
 * nChiffre si != 0 alors le chiffre retourne contient nChiffre decimal
 *			si = 0 alors le chiffre retourne a une taille variable.
 * ex : convertNum(10, buf, 6); -> Retourne 000010.
 * ex : convertNum(10, buf, 0); -> Retourne 10.
 */
extern char* convertNum(long num, char* buf, unsigned int nRightShift);

/** M�thode � �viter, pArg pointe sur le prochain argument */
extern unsigned short print(const char* string, const char** pArg, unsigned short row, unsigned short col, unsigned short nLeftBorder, unsigned short nRightBorder COLORPARAMDEF);

/** Print2 (caracteres speciaux a mettre dans la chaine 'string')
 * \n	: retour a la ligne
 * %i,%l: pour indiquer qu'un entier doit place (%i = int et %l = long)
 * %.ni : pour indiquer la taille du chiffre (n de 0 a 9)
 * %.nl : idem que ci-dessus mais pour un entier de type long
 * \t	: saut de 4 caract�res (hors retour � la ligne, != 4 espaces)
 */
/** 0<= x < 128, 0 <= y < 63 */   
extern unsigned short print2(unsigned short x, unsigned short y, const char* string COLORPARAMDEF, ...);

/** Affiche un texte sur une ligne (Centr�, � gauche ou � droite) */
extern void alignPrint(const char* text, int nYPos, unsigned short nLeftBorder, unsigned short nRightBorder, TEXTALIGN align COLORPARAMDEF);

#endif   
