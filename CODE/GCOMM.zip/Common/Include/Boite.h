/************************************************************************
 *                                                                      *
 *                  Boites de dialogue Version 1.10                     *
 *                                                                      *
 * Permet d'affiche des boites de dialogue � l'�cran.                   *
 * D�pend de DadaAscii et Graphic.                                      *
 *                                                                      *
 * Auteur : dada66 (david.quaranta@laposte.net)                         *
 * (C) Copyright 2003-2004 Quaranta Software                            *
 ************************************************************************/

#ifndef _BOITE_H
#define _BOITE_H                  

#include <keys.h>  

/** Masque permettant de savoir dans quel mode on se trouve */
#define MASK_SHIFT 1
#define MASK_ALPHA 2
#define MASK_MIN   4 
/** Permet de r�gler des modes pour InputText et InputBoxString */
#define MODE_DIGIT 0
#define MODE_MAJ   MASK_ALPHA
#define MODE_MIN   MASK_ALPHA | MASK_MIN


#define BLEND_OPAQUE      0
#define BLEND_TRANSPARENT 1

#ifdef GREY_MODE
#define BLEND_PARAM , int nBlendMode
#else
#define BLEND_PARAM
#endif
                                                  
extern int ltr[];
extern int chiffres[];
/** Compteur interne de la G100
 * Utilis� pour g�rer le clignotement du curseur
 */
extern unsigned int far* internal_cpt;

/** Besoin de d�clarer ces variables pour avoir du texte dans les
 * boites de dialogue
 */
extern char msg_cancel[];
extern char msg_ok[];
extern char msg_yes[];
extern char msg_no[];

/** Besoin d'impl�menter ces m�thodes */
extern int  ReadKey(); 
extern int  WaitKey();

/** M�thodes internes, ne pas utiliser de pr�f�rence */
void ShowOkCancel(int y);

/** Affiche une boite de dialogue
 * Utilis�e par la toutes les fonctions ci-dessous.
 * Affiche un texte et ces param�tre en utilisant print2 de 'ascii.h',
 * donc supporte les "%s", "%i", ...
 * Le retour � la ligne est automatique afin de ne pas sortir de la boite de dialogue
 * par contre si le texte est trop long pour rentrer dans l'�cran le r�sultat � l'�cran
 * peut �tre horrible vu que cette ne m�thode de v�rifie pas les d�passements verticaux.
 */
int  Box(const char* message, const char** pointer, int large);         

/** Cr�e une boite de de saisie (ie. affiche ANNULER) */
int  InputBox(const char* message);

/** Copie un string et retourne la taille */
extern int  CopyChar(char* dest, const char* source);

/** Permet de saisir du texte
 * x-y    : coordonn�es
 * buffer : tampon pour recevoir la chaine saisie
 * max    : nombre de caract�re maximal
 * insert : sp�cifie si oui ou non on est en mode insert
 * mode   : sp�cifie le mode de saisie
 * bClearBuffer : Si !=0, alors efface le buffer en param�tre
 * Retourne 1 si l'utilisateur "Valide"
 */
extern int  InputText(short x, short y, char* buffer, int max, int& insert, int& mode, int bClearBuffer);

/** Ferme un boite de dialogue
 * Ne sert que pour ShowProgressPopup, et est utilis� en interne
 */
extern void CloseBox();

/** Ouvre une boite de dialogue toute simple
 * format : 0 -> Affiche le texte + OK
 *          1 -> Affiche le texte + OUI ou NON
 * message : Message � afficher (G�re les %s, %i, ... de 'ascii.h')
 * Retourne 1 si la touche press�e est [EXE], sinon 0
 */
extern int  MsgBox(int format, const char* message, ...);

/** Demande la saisie d'un nombre de 0 � max
 * Retourne -1 si l'utilisateur annule, sinon le nombre saisie
 */
extern long InputBoxNum(const char* message, long max);

/** Ouvre un boite de dialogue afin de saisir du texte
 * Utilise la m�thode InputText donc les param�tres sont identiques
 */
extern int  InputBoxString(const char* message, char* buffer, const int max, int insert, int mode, int bClearBuffer);

/** Affiche un popup de progression
 * bShowCancel !=0 affiche message d'annulation
 * nPercent pourcentage accompli (nPercent < 0 implique que la barre de pourcentage n'est pas affich�e)
 * string : Texte � afficher.
 * Si string == 0 juste la barre de progression est affich�e, sinon une nouvelle boite de dialogue s'affiche. (Appel juste Box(), pas de CloseBox())
 * Besoin d'apppeler CloseBox() pour fermer la fenetre
 * nBlendMode (Mode Gris seulement) : Permet de choisir une boite de dialogue partiellement
 * transparente (Juste pour la premi�re couche, SEG1)
 */
extern void ShowProgressPopup(int bShowCancel, int nPercent BLEND_PARAM, const char* string, ...);

/** Affiche un popup de saisie de plusieurs textes (Affiche une sorte de ComboBox)
 * text : Texte � afficher
 * num  : Nombre de lignes
 * Retourne -1 si l'utilisateur annule
 */
extern int  ShowInputPopup(char** text, int num);

#endif
