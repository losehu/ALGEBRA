/************************************************************************
 *                                                                      *
 *                          Graphic                                     *
 *                                                                      *
 * Permet de dessiner sur  l'�cran de votre Graph100.                   *
 * Interface g�rant le mode C3 et le mode DB                            *
 *                                                                      *
 * Auteur : dada66 (david.quaranta@laposte.net)                         *
 * (C) Copyright 2003-2004 Quaranta Software                            *
 ************************************************************************/

#ifndef GRAPHIC_H
#define GRAPHIC_H

#define SEG1 0x1A20
#define SEG2 0x1A60
#define SEG3 0x1AA0
#define SEG4 0x1AE0

#ifdef GREY_MODE
#define SPRITE_BW    0 
#define SPRITE_GW    1
#define SPRITE_GREY  2
#endif

#ifdef __cplusplus
extern "C" {
#endif
 
/** Efface l'�cran */
void clear();
/** Efface un segment (SEG1, SEG2, ...) */
void ClearPage(short page, short nNbWord);
/** Copie un segment */
void CopyPage(int S1, int S2);
/** Inverse un pixel */
void invPix(unsigned short x, unsigned short y);
/** D�fini l'�tat d'un pixel */
void setPix(unsigned short x, unsigned short y, short state);
void vLine(unsigned short x, unsigned short y1, unsigned short y2, short state);
void hLine(unsigned short x1, unsigned short y, unsigned short x2, short state);
void invhLine(unsigned short x1, unsigned short y, unsigned short x2);
void Rect(int x1, int y1, int x2, int y2, short value);
 
/** Decale l'�cran verticalement
 * x1 : premier octet horizontal (min 0 max 16) (gauche)
 * x2 : dernier octet horizontal (min 0 max 16) (droite)
 * y1 : premier pixel vertical   (min 0 max 63) (haut)
 * y2 : dernier pixel vertical   (min 0 max 63) (bas)
 * nShift : decalage en pixel ( > 0 decale du bas vers le haut, et < 0 du haut vers le bas)
 */
void vShift(int x1, int x2, int y1, int y2, int nShift);

#ifdef GREY_MODE
void EnableGreyMode();
void DisableGreyMode(); 
void DrawSprite(unsigned short x, unsigned short y, const void* sprite, unsigned short mask, short height, char flag);
void DrawSprite2(unsigned short x, unsigned short y, unsigned int nSeg, unsigned int nOffset, unsigned short mask, short height, char flag);
#else
void DrawSprite(unsigned short x, unsigned short y, const void* sprite, unsigned short mask, short height);
void DrawSprite2(unsigned short x, unsigned short y, unsigned int nSeg, unsigned int nOffset, unsigned short mask, short height);
#endif

#ifdef __cplusplus
}
#endif

#endif
